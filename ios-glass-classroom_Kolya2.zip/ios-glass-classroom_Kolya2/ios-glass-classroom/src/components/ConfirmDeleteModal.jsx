import React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { AlertTriangle, Trash2, X } from 'lucide-react'
import GlassCard from './GlassCard'

export default function ConfirmDeleteModal({ 
  isOpen, 
  onClose, 
  onConfirm, 
  title, 
  message, 
  confirmText = 'Удалить',
  cancelText = 'Отмена',
  type = 'danger'
}) {
  if (!isOpen) return null

  const getTypeStyles = () => {
    switch (type) {
      case 'danger':
        return {
          icon: <Trash2 size={24} className="text-red-400" />,
          button: 'bg-red-500 hover:bg-red-600 text-white',
          border: 'border-red-500/20',
          bg: 'bg-red-500/10'
        }
      case 'warning':
        return {
          icon: <AlertTriangle size={24} className="text-yellow-400" />,
          button: 'bg-yellow-500 hover:bg-yellow-600 text-white',
          border: 'border-yellow-500/20',
          bg: 'bg-yellow-500/10'
        }
      default:
        return {
          icon: <AlertTriangle size={24} className="text-blue-400" />,
          button: 'bg-blue-500 hover:bg-blue-600 text-white',
          border: 'border-blue-500/20',
          bg: 'bg-blue-500/10'
        }
    }
  }

  const styles = getTypeStyles()

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.9, opacity: 0, y: 20 }}
          transition={{ type: 'spring', damping: 25, stiffness: 300 }}
          className="w-full max-w-md"
          onClick={(e) => e.stopPropagation()}
        >
          <GlassCard className={`p-6 border ${styles.border} ${styles.bg}`}>
            {/* Header */}
            <div className="flex items-center gap-3 mb-4">
              <div className={`glass rounded-full p-2 ${styles.bg}`}>
                {styles.icon}
              </div>
              <div className="flex-1">
                <h3 className="text-lg font-semibold">{title}</h3>
              </div>
              <button
                onClick={onClose}
                className="glass rounded-full p-2 hover:bg-white/10 transition-colors"
              >
                <X size={18} />
              </button>
            </div>

            {/* Message */}
            <div className="mb-6">
              <p className="text-sm text-muted leading-relaxed">{message}</p>
            </div>

            {/* Actions */}
            <div className="flex gap-3">
              <button
                onClick={onClose}
                className="flex-1 glass rounded-xl px-4 py-3 text-sm font-medium transition-colors hover:bg-white/10"
              >
                {cancelText}
              </button>
              <button
                onClick={() => {
                  onConfirm()
                  onClose()
                }}
                className={`flex-1 rounded-xl px-4 py-3 text-sm font-medium transition-colors ${styles.button}`}
              >
                {confirmText}
              </button>
            </div>
          </GlassCard>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  )
}
