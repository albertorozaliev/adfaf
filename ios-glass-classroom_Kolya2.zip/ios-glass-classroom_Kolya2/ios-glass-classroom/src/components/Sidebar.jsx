import React from 'react'
import { Home, FolderClosed, Clock, Settings, Info, Users, Rss, BookOpen, GraduationCap, MessagesSquare} from 'lucide-react'
import { NavLink, useLocation } from 'react-router-dom'
import { useLanguage } from '../context/LanguageContext'

const Item = ({ to, icon: Icon, label }) => (
  <NavLink
    to={to}
    className={({ isActive }) => `glass rounded-2xl px-3 py-2.5 flex items-center gap-2.5 transition ${
      isActive ? 'ring-1 ring-white/20 bg-white/10' : 'hover:bg-white/5'
    }`}
  >
    <Icon size={16} />
    <span className="text-sm">{label}</span>
  </NavLink>
)

export default function Sidebar() {
  const location = useLocation()
  const { t } = useLanguage()
  const isCourseDetail = location.pathname.startsWith('/course/') && !location.pathname.includes('/assignment/')

  if (isCourseDetail) {
    return (
      <aside className="hidden md:flex md:flex-col gap-3 w-40 lg:w-56 p-3 sticky top-24 h-[calc(100vh-8rem)] flex-shrink-0 content-scroll">
        <Item to="/my-courses" icon={FolderClosed} label={t('back_to_courses')} />
      </aside>
    )
  }

  return (
    <aside className="hidden md:flex md:flex-col gap-3 w-40 lg:w-56 p-3 sticky top-24 h-[calc(100vh-8rem)] flex-shrink-0 content-scroll">
      <Item to="/mainwindow" icon={Info} label={t('Главная')} />
      <Item to="/overview" icon={Home} label={t('overview')} />
      <Item to="/my-courses" icon={FolderClosed} label={t('my_courses')} />
      <Item to="/recent" icon={Clock} label={t('recent')} />
      <Item to="/settings" icon={Settings} label={t('settings')} />
        <Item to="/mainwindow" icon={MessagesSquare} label={t('GlassChat')} />
    </aside>
  )
}
