import React, { useState, useEffect } from 'react'
import { LogOut, PlusCircle, X, Home, Book, Clock, Settings, Archive } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import { signOut, getUser } from '../lib/auth'
import { useLanguage } from '../context/LanguageContext'
import { useNavigate } from 'react-router-dom'

export default function NavBar({ onNewCourse }) {
  const user = getUser()
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isMobile, setIsMobile] = useState(false)
  const { t } = useLanguage()
  const navigate = useNavigate()

  // Определяем роль пользователя
  const userRole = user?.role || 'student'
  const userName = user?.name || 'Пользователь'

  // Определяем мобильное устройство
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768)
    }
    
    checkMobile()
    window.addEventListener('resize', checkMobile)
    return () => window.removeEventListener('resize', checkMobile)
  }, [])

  const menuVariants = {
    hidden: { opacity: 0, scale: 0.95 },
    visible: { opacity: 1, scale: 1, transition: { staggerChildren: 0.1 } },
    exit: { opacity: 0, scale: 0.95 },
  }

  const itemVariants = { hidden: { opacity: 0, y: 20 }, visible: { opacity: 1, y: 0 } }

  const handleNavigate = (path) => {
    navigate(path)
    setIsMenuOpen(false)
  }

  // Мобильная версия
  if (isMobile) {
    return (
      <>
        {/* Верхняя панель для мобильных */}
        <motion.div 
          className="glass fixed top-4 left-4 right-4 z-40 rounded-full px-4 py-2 flex items-center justify-between gap-3 shadow-glass shine"
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
        >
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsMenuOpen(true)}
              className="w-8 h-8 rounded-xl flex items-center justify-center bg-white/10 hover:bg-white/20 transition-colors"
            >
              <div className="w-5 h-5 rounded-lg bg-white/30"></div>
            </button>
            <span className="text-sm text-ink/80">Glassroom</span>
          </div>

          <div className="flex items-center gap-2">
            <button onClick={onNewCourse} className="glass px-3 py-1.5 rounded-full text-sm flex items-center gap-2">
              <PlusCircle size={16} /> {t('create_course')}
            </button>
            <div className="w-7 h-7 rounded-full bg-white/20 overflow-hidden ring-1 ring-white/20">
              <img alt="avatar" src={`https://api.dicebear.com/9.x/identicon/svg?seed=${user?.email || 'guest'}`} />
            </div>
          </div>
        </motion.div>

        {/* Модальное меню для мобильных */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-md"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <motion.div
                className="relative glass p-6 rounded-2xl flex flex-col gap-4 w-72"
                variants={menuVariants}
                initial="hidden"
                animate="visible"
                exit="exit"
              >
                <button
                  onClick={() => setIsMenuOpen(false)}
                  className="absolute -top-3 -right-3 glass rounded-full p-1 hover:bg-red-500/20 transition-colors"
                >
                  <X size={18} />
                </button>

                {/* Информация о пользователе в меню */}
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-full bg-white/20 overflow-hidden ring-1 ring-white/20">
                    <img alt="avatar" src={`https://api.dicebear.com/9.x/identicon/svg?seed=${user?.email || 'guest'}`} />
                  </div>
                  <div>
                    <div className="text-sm font-medium">{userName}</div>
                    <div className="text-xs text-ink/60 capitalize">
                      {userRole === 'student' ? 'Студент' : 'Преподаватель'}
                    </div>
                  </div>
                </div>

                {/* Пункты меню */}
                <motion.button
                  variants={itemVariants}
                  className="glass px-4 py-3 rounded-xl flex items-center gap-3 text-ink hover:bg-white/10 transition-colors"
                  onClick={() => handleNavigate('/overview')}
                >
                  <Home size={18} /> {t('overview')}
                </motion.button>

                <motion.button
                  variants={itemVariants}
                  className="glass px-4 py-3 rounded-xl flex items-center gap-3 text-ink hover:bg-white/10 transition-colors"
                  onClick={() => handleNavigate('/my-courses')}
                >
                  <Book size={18} /> {t('my_courses')}
                </motion.button>

                <motion.button
                  variants={itemVariants}
                  className="glass px-4 py-3 rounded-xl flex items-center gap-3 text-ink hover:bg-white/10 transition-colors"
                  onClick={() => handleNavigate('/recent')}
                >
                  <Clock size={18} /> {t('recent')}
                </motion.button>

                <motion.button
                  variants={itemVariants}
                  className="glass px-4 py-3 rounded-xl flex items-center gap-3 text-ink hover:bg-white/10 transition-colors"
                  onClick={() => handleNavigate('/settings')}
                >
                  <Settings size={18} /> {t('settings')}
                </motion.button>

                <motion.button
                  variants={itemVariants}
                  className="glass px-4 py-3 rounded-xl flex items-center gap-3 text-ink hover:bg-white/10 transition-colors"
                  onClick={() => handleNavigate('/archive')}
                >
                  <Archive size={18} /> {t('Архив')}
                </motion.button>

                <motion.button
                  variants={itemVariants}
                  className="glass px-4 py-3 rounded-xl flex items-center gap-3 text-ink hover:bg-white/10 transition-colors"
                  onClick={() => handleNavigate('/GlassChat')}
                >
                  <Archive size={18} /> {t('GlassChat')}
                </motion.button>

                {/* Кнопка выхода */}
                <motion.button
                  variants={itemVariants}
                  className="glass px-4 py-3 rounded-xl flex items-center gap-3 text-ink hover:bg-red-500/20 transition-colors mt-4"
                  onClick={() => { signOut(); location.href = '/signin'; }}
                >
                  <LogOut size={18} /> {t('sign_out')}
                </motion.button>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </>
    )
  }

  // Десктопная версия
  return (
    <motion.div
      className="glass fixed top-4 left-4 right-4 z-40 rounded-full px-6 py-3 flex items-center justify-between gap-3 shadow-glass shine"
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
    >
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 rounded-xl bg-white/10 backdrop-blur flex items-center justify-center">
          <div className="w-5 h-5 rounded-lg bg-white/30"></div>
        </div>
        <span className="text-sm text-ink/80">Glassroom</span>
      </div>
      
      <div className="flex items-center gap-3">
        {/* Блок с ролью пользователя */}
        <div className="glass px-4 py-2 rounded-full text-sm">
          <span className="text-ink/80 capitalize">
            {userRole === 'student' ? 'Студент' : 'Преподаватель'}
          </span>
        </div>
        
        {/* Блок с ФИО пользователя */}
        <div className="glass px-4 py-2 rounded-full text-sm">
          <span className="text-ink">{userName}</span>
        </div>
        
        <div className="w-7 h-7 rounded-full bg-white/20 backdrop-blur overflow-hidden ring-1 ring-white/20">
          <img alt="avatar" src={`https://api.dicebear.com/9.x/identicon/svg?seed=${user?.email || 'guest'}`} />
        </div>
        
        <button
          onClick={() => { signOut(); location.href = '/signin'; }}
          className="glass px-3 py-1.5 rounded-full text-sm hover:scale-[1.02] active:scale-[0.99] transition inline-flex items-center gap-1"
          title="Sign out"
        >
          <LogOut size={16} />
        </button>
      </div>
    </motion.div>
  )
}