import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Mail, Plus, Trash2 } from 'lucide-react';
import GlassCard from './GlassCard';
import emailjs from '@emailjs/browser';

export default function EmailNotificationSender({ isOpen, onClose, onSend }) {
  const [emails, setEmails] = useState(['']);
  const [message, setMessage] = useState('');
  const [sending, setSending] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setEmails(['']);
      setMessage('');
      setSending(false);
    }
  }, [isOpen]);

  const handleClose = () => {
    setEmails(['']);
    setMessage('');
    setSending(false);
    onClose();
  };

  const addEmail = () => {
    setEmails(prev => [...prev, '']);
  };

  const updateEmail = (index, value) => {
    setEmails(prev => prev.map((email, i) => i === index ? value : email));
  };

  const removeEmail = (index) => {
    setEmails(prev => prev.filter((_, i) => i !== index));
  };

  const handleSend = async () => {
    const validEmails = emails.filter(email => email.trim() !== '');
    if (validEmails.length === 0 || !message.trim()) return;
    setSending(true);
    let success = true;
    for (const email of validEmails) {
      try {
        await emailjs.send(
          'YOUR_SERVICE_ID',
          'YOUR_TEMPLATE_ID',
          {
            user_email: email,
            message: message,
          },
          'YOUR_PUBLIC_KEY'
        );
      } catch (err) {
        success = false;
        console.error('FAILED...', err.text);
      }
    }
    setSending(false);
    if (success) {
      onSend && onSend({ emails: validEmails, message });
      handleClose();
    } else {
      alert('Ошибка при отправке писем.');
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
          onClick={handleClose}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="w-full max-w-lg"
            onClick={e => e.stopPropagation()}
          >
            <GlassCard className="p-6 space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-semibold">Отправить уведомление на Email</h2>
                  <p className="text-sm text-muted">Введите email-адреса и сообщение</p>
                </div>
                <button
                  onClick={handleClose}
                  className="glass rounded-full p-2 hover:bg-white/10 transition-colors"
                >
                  <X size={18} />
                </button>
              </div>

              <div className="space-y-3">
                {emails.map((email, idx) => (
                  <div key={idx} className="flex items-center gap-2">
                    <Mail size={16} className="text-blue-400" />
                    <input
                      type="email"
                      value={email}
                      onChange={e => updateEmail(idx, e.target.value)}
                      placeholder="Email"
                      className="input glass px-3 py-2 rounded w-full"
                    />
                    {emails.length > 1 && (
                      <button onClick={() => removeEmail(idx)} className="glass rounded-full p-1">
                        <Trash2 size={14} />
                      </button>
                    )}
                  </div>
                ))}
                <button onClick={addEmail} className="glass rounded-full px-2 py-1 flex items-center gap-1">
                  <Plus size={14} /> <span className="text-xs">Добавить Email</span>
                </button>
              </div>

              <textarea
                value={message}
                onChange={e => setMessage(e.target.value)}
                placeholder="Сообщение"
                className="input glass px-3 py-2 rounded w-full min-h-[80px]"
              />

              <button
                onClick={handleSend}
                disabled={sending}
                className={`bg-blue-500 text-white px-4 py-2 rounded-full mt-2 hover:bg-blue-600 transition-colors ${sending ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                {sending ? 'Отправка...' : 'Отправить'}
              </button>
            </GlassCard>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
