import React, { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { X, Upload, Link, HardDrive, FileText, Plus, Trash2 } from 'lucide-react'
import GlassCard from './GlassCard'

export default function AttachmentModal({ isOpen, onClose, onAttach }) {
  const [activeTab, setActiveTab] = useState('computer')
  const [files, setFiles] = useState([])
  const [links, setLinks] = useState([''])
  const [driveFiles, setDriveFiles] = useState([])

  // Сброс состояния при открытии модального окна
  useEffect(() => {
    if (isOpen) {
      setFiles([])
      setLinks([''])
      setDriveFiles([])
      setActiveTab('computer')
    }
  }, [isOpen])

  // Сброс состояния при закрытии модального окна
  const handleClose = () => {
    setFiles([])
    setLinks([''])
    setDriveFiles([])
    setActiveTab('computer')
    onClose()
  }

  const handleFileSelect = (e) => {
    const selectedFiles = Array.from(e.target.files)
    setFiles(prev => [...prev, ...selectedFiles])
  }

  const removeFile = (index) => {
    setFiles(prev => prev.filter((_, i) => i !== index))
  }

  const addLink = () => {
    setLinks(prev => [...prev, ''])
  }

  const updateLink = (index, value) => {
    setLinks(prev => prev.map((link, i) => i === index ? value : link))
  }

  const removeLink = (index) => {
    setLinks(prev => prev.filter((_, i) => i !== index))
  }

  const openGoogleDrive = () => {
    // В реальном приложении здесь была бы интеграция с Google Drive API
    // Для демонстрации добавляем тестовый файл
    setDriveFiles(prev => [...prev, { name: 'Документ из Google Drive.docx' }])
    window.open('https://drive.google.com', '_blank')
  }

  const handleSubmit = () => {
    const attachments = {
      files: files,
      links: links.filter(link => link.trim() !== ''),
      driveFiles: driveFiles
    }
    onAttach(attachments)
    handleClose()
  }

  const TabButton = ({ id, icon: Icon, label, active, onClick }) => (
    <button
      onClick={onClick}
      className={`flex items-center gap-2 px-4 py-2 rounded-2xl transition-colors ${
        active ? 'glass ring-1 ring-white/20 bg-white/10' : 'hover:bg-white/5'
      }`}
    >
      <Icon size={16} />
      <span className="text-sm">{label}</span>
    </button>
  )

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
          onClick={handleClose}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="w-full max-w-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <GlassCard className="p-6 space-y-6">
              {/* Header */}
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-semibold">Прикрепить работу</h2>
                  <p className="text-sm text-muted">Выберите способ прикрепления файлов</p>
                </div>
                <button
                  onClick={handleClose}
                  className="glass rounded-full p-2 hover:bg-white/10 transition-colors"
                >
                  <X size={18} />
                </button>
              </div>
              
              {/* Tab Navigation */}
              <div className="flex gap-2">
                <TabButton
                  id="computer"
                  icon={Upload}
                  label="Компьютер"
                  active={activeTab === 'computer'}
                  onClick={() => setActiveTab('computer')}
                />
                <TabButton
                  id="drive"
                  icon={HardDrive}
                  label="Google Drive"
                  active={activeTab === 'drive'}
                  onClick={() => setActiveTab('drive')}
                />
                <TabButton
                  id="link"
                  icon={Link}
                  label="Ссылка"
                  active={activeTab === 'link'}
                  onClick={() => setActiveTab('link')}
                />
              </div>

              {/* Tab Content */}
              <div className="space-y-4">
                {activeTab === 'computer' && (
                  <div className="space-y-4">
                    <div className="glass rounded-2xl p-6 border-2 border-dashed border-white/20 hover:border-white/40 transition-colors">
                      <input
                        type="file"
                        multiple
                        onChange={handleFileSelect}
                        className="hidden"
                        id="file-input"
                      />
                      <label
                        htmlFor="file-input"
                        className="flex flex-col items-center gap-3 cursor-pointer"
                      >
                        <Upload size={32} className="text-muted" />
                        <div className="text-center">
                          <div className="font-medium">Выберите файлы</div>
                          <div className="text-sm text-muted">или перетащите их сюда</div>
                        </div>
                      </label>
                    </div>
                    
                    {files.length > 0 && (
                      <div className="space-y-2">
                        <div className="text-sm font-medium">Выбранные файлы:</div>
                        {files.map((file, index) => (
                          <div key={index} className="glass rounded-xl p-3 flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <FileText size={16} />
                              <div>
                                <div className="text-sm font-medium">{file.name}</div>
                                <div className="text-xs text-muted">{(file.size / 1024 / 1024).toFixed(2)} MB</div>
                              </div>
                            </div>
                            <button
                              onClick={() => removeFile(index)}
                              className="glass rounded-full p-1 hover:bg-red-500/20 transition-colors"
                            >
                              <Trash2 size={14} className="text-red-400" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {activeTab === 'drive' && (
                  <div className="space-y-4">
                    <div className="glass rounded-2xl p-6 text-center">
                      <HardDrive size={48} className="text-muted mx-auto mb-4" />
                      <div className="font-medium mb-2">Google Drive</div>
                      <div className="text-sm text-muted mb-4">
                        Откройте Google Drive для выбора файлов
                      </div>
                      <button
                        onClick={openGoogleDrive}
                        className="glass rounded-xl px-6 py-3 hover:bg-white/10 transition-colors"
                      >
                        Открыть Google Drive
                      </button>
                    </div>
                    
                    {driveFiles.length > 0 && (
                      <div className="space-y-2">
                        <div className="text-sm font-medium">Файлы из Google Drive:</div>
                        {driveFiles.map((file, index) => (
                          <div key={index} className="glass rounded-xl p-3 flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <FileText size={16} />
                              <div className="text-sm font-medium">{file.name}</div>
                            </div>
                            <button
                              onClick={() => setDriveFiles(prev => prev.filter((_, i) => i !== index))}
                              className="glass rounded-full p-1 hover:bg-red-500/20 transition-colors"
                            >
                              <Trash2 size={14} className="text-red-400" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {activeTab === 'link' && (
                  <div className="space-y-4">
                    <div className="space-y-3">
                      {links.map((link, index) => (
                        <div key={index} className="flex gap-2">
                          <input
                            type="url"
                            value={link}
                            onChange={(e) => updateLink(index, e.target.value)}
                            placeholder="Введите ссылку на файл..."
                            className="flex-1 glass rounded-xl px-4 py-3 bg-transparent border border-white/10 focus:border-white/20 outline-none transition-colors"
                          />
                          {links.length > 1 && (
                            <button
                              onClick={() => removeLink(index)}
                              className="glass rounded-xl px-3 hover:bg-red-500/20 transition-colors"
                            >
                              <Trash2 size={16} className="text-red-400" />
                            </button>
                          )}
                        </div>
                      ))}
                      <button
                        onClick={addLink}
                        className="glass rounded-xl px-4 py-3 hover:bg-white/10 transition-colors flex items-center gap-2"
                      >
                        <Plus size={16} />
                        Добавить ссылку
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Actions */}
              <div className="flex gap-3 pt-4 border-t border-white/10">
                <button
                  onClick={handleClose}
                  className="flex-1 glass rounded-xl px-4 py-3 hover:bg-white/10 transition-colors"
                >
                  Отмена
                </button>
                <button
                  onClick={handleSubmit}
                  className="flex-1 glass rounded-xl px-4 py-3 bg-blue-500/20 hover:bg-blue-500/30 transition-colors"
                >
                  Прикрепить
                </button>
              </div>
            </GlassCard>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
