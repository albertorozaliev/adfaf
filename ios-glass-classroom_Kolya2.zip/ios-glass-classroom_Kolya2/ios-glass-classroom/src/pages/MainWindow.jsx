import React from 'react';
import GlassCard from '../components/GlassCard';
import { motion } from 'framer-motion';

export default function MainWindow() {
  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <GlassCard className="p-8 text-center">
          <div className="text-3xl font-bold mb-4">Добро пожаловать!</div>
          <div className="text-muted text-lg mb-6">Мы рады приветствовать вас на нашей образовательной платформе</div>
          <div className="flex justify-center">
          </div>
        </GlassCard>
      </motion.div>

      <GlassCard className="flex items-center justify-between">
        <div>
          <div className="text-xl font-semibold">Мои Курсы</div>
          <div className="text-muted text-sm">Все ваши курсы в одном месте</div>
        </div>
        <div className="text-xs glass rounded-full px-3 py-1">Активно</div>
      </GlassCard>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <GlassCard className="p-6">
            <div className="flex items-start mb-4">
              <div className="bg-blue-500/20 p-2 rounded-lg mr-4">
                <svg className="w-6 h-6 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                </svg>
              </div>
              <div>
                <div className="font-medium">Доступ к материалам</div>
                <div className="text-muted text-sm">Все лекции и задания в одном месте</div>
              </div>
            </div>
          </GlassCard>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
        >
          <GlassCard className="p-6">
            <div className="flex items-start mb-4">
              <div className="bg-green-500/20 p-2 rounded-lg mr-4">
                <svg className="w-6 h-6 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                </svg>
              </div>
              <div>
                <div className="font-medium">Преподаватели</div>
                <div className="text-muted text-sm">Связь с преподавателями курсов</div>
              </div>
            </div>
          </GlassCard>
        </motion.div>
<motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          <GlassCard className="p-6">
            <div className="flex items-start mb-4">
              <div className="bg-purple-500/20 p-2 rounded-lg mr-4">
                <svg className="w-6 h-6 text-purple-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                </svg>
              </div>
              <div>
                <div className="font-medium">Удобный интерфейс</div>
                <div className="text-muted text-sm">Интуитивная навигация по платформе</div>
              </div>
            </div>
          </GlassCard>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
        >
          <GlassCard className="p-6">
            <div className="flex items-start mb-4">
              <div className="bg-yellow-500/20 p-2 rounded-lg mr-4">
                <svg className="w-6 h-6 text-yellow-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <div>
                <div className="font-medium">Экономия времени</div>
                <div className="text-muted text-sm">Быстрый доступ ко всем ресурсам</div>
              </div>
            </div>
          </GlassCard>
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.6 }}
      >
        <GlassCard className="p-6">
          <div className="text-lg font-medium mb-4">Как начать работу?</div>
          <ol className="list-decimal list-inside space-y-2 text-muted">
            <li>Выберите интересующий курс из меню слева</li>
            <li>Ознакомьтесь с материалами и заданиями</li>
            <li>Следите за обновлениями и дедлайнами</li>
            <li>При необходимости свяжитесь с преподавателем</li>
          </ol>
        </GlassCard>
      </motion.div>
    </div>
  );
}