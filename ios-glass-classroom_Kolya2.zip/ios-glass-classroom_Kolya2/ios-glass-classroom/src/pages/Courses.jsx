import React from 'react'
import CourseCard from '../components/CourseCard'
import GlassCard from '../components/GlassCard'
import { motion } from 'framer-motion'
import { useNavigate } from 'react-router-dom'
import { useCourses } from '../hooks/useCourses'

export default function Courses() {
  const navigate = useNavigate()
  const { getActiveCourses } = useCourses()
  const courses = getActiveCourses()

  return (
    <div className="space-y-6">
      <GlassCard className="flex items-center justify-between">
        <div>
          <div className="text-xl font-semibold">Добро пожаловать 👋</div>
          <div className="text-muted text-sm">Ваши активные курсы</div>
        </div>
        <div className="text-xs glass rounded-full px-3 py-1">Dark · Liquid Glass</div>
      </GlassCard>

      {courses.length === 0 ? (
        <p className="text-muted">У вас пока нет активных курсов.</p>
      ) : (
        <motion.div
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
          initial="hidden"
          animate="show"
          variants={{ hidden: {}, show: { transition: { staggerChildren: 0.06 } } }}
        >
          {courses.map((course) => (
            <motion.div 
              key={course.id} 
              variants={{ hidden: { opacity: 0, y: 12 }, show: { opacity: 1, y: 0 } }}
            >
              <CourseCard
                {...course}
                onClick={() => navigate(`/courses/${course.id}`)}
              />
            </motion.div>
          ))}
        </motion.div>
      )}
    </div>
  )
}
