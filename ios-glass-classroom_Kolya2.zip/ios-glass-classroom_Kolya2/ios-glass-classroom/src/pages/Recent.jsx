import React from 'react'
import GlassCard from '../components/GlassCard'
import { motion } from 'framer-motion'
import { Clock, BookOpen, User, Calendar, Plus, GraduationCap, FileCheck, Star } from 'lucide-react'
import { useHistory } from '../hooks/useHistory'
import { useNavigate } from 'react-router-dom'

const getEventIcon = (type) => {
  switch (type) {
    case 'assignment_created':
      return <BookOpen size={16} />
    case 'course_created':
      return <GraduationCap size={16} />
    case 'assignment_submitted':
      return <FileCheck size={16} />
    case 'grade_assigned':
      return <Star size={16} />
    default:
      return <BookOpen size={16} />
  }
}

const getEventColor = (type) => {
  switch (type) {
    case 'assignment_created':
      return 'text-blue-400'
    case 'course_created':
      return 'text-green-400'
    case 'assignment_submitted':
      return 'text-purple-400'
    case 'grade_assigned':
      return 'text-yellow-400'
    default:
      return 'text-blue-400'
  }
}

const NotificationCard = ({ event, onClick }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.4 }}
  >
    <GlassCard 
      className="p-6 hover:bg-white/5 transition-colors cursor-pointer"
      onClick={onClick}
    >
      <div className="flex items-start gap-4">
        <div className={`glass rounded-full p-2 flex-shrink-0 ${getEventColor(event.type)}`}>
          {getEventIcon(event.type)}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-medium text-sm">{event.title}</h3>
            <span className="text-xs text-muted flex items-center gap-1">
              <Clock size={12} />
              {event.time}
            </span>
          </div>
          <p className="text-sm text-muted mb-3">{event.description}</p>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-xs glass rounded-full px-2 py-1">{event.course}</span>
              {event.teacher && (
                <span className="text-xs text-muted flex items-center gap-1">
                  <User size={12} />
                  {event.teacher}
                </span>
              )}
            </div>
            {event.dueDate && (
              <div className="flex items-center gap-1 text-xs text-muted">
                <Calendar size={12} />
                {new Date(event.dueDate).toLocaleDateString('ru-RU', {
                  day: 'numeric',
                  month: 'short'
                })}
              </div>
            )}
            {event.grade && (
              <div className="flex items-center gap-1 text-xs text-yellow-400">
                <Star size={12} />
                {event.grade}/5
              </div>
            )}
          </div>
        </div>
      </div>
    </GlassCard>
  </motion.div>
)

export default function Recent() {
  const { getRecentHistory, formatEventTime } = useHistory()
  const navigate = useNavigate()
  const recentEvents = getRecentHistory(20)

  const handleEventClick = (event) => {
    if (event.type === 'assignment_created' && event.assignmentId) {
      navigate(`/course/${event.courseId}/assignment/${event.assignmentId}`)
    } else if (event.courseId) {
      navigate(`/course/${event.courseId}`)
    }
  }

  const eventsWithTime = recentEvents.map(event => ({
    ...event,
    time: formatEventTime(event.createdAt)
  }))

  return (
    <div className="space-y-6 content-scroll">
      <GlassCard className="flex items-center justify-between">
        <div>
          <div className="text-xl font-semibold">Недавняя Активность</div>
          <div className="text-muted text-sm">Последние задания и обновления</div>
        </div>
        <div className="text-xs glass rounded-full px-3 py-1">{recentEvents.length} Обновлений</div>
      </GlassCard>

      <div className="space-y-4">
        {eventsWithTime.length > 0 ? (
          eventsWithTime.map((event) => (
            <NotificationCard 
              key={event.id} 
              event={event} 
              onClick={() => handleEventClick(event)}
            />
          ))
        ) : (
          <GlassCard className="p-8 text-center">
            <div className="text-muted">
              <BookOpen className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p className="text-lg mb-2">Пока нет активности</p>
              <p className="text-sm">Создайте курс или задание, чтобы увидеть уведомления здесь</p>
            </div>
          </GlassCard>
        )}
      </div>
    </div>
  )
}
