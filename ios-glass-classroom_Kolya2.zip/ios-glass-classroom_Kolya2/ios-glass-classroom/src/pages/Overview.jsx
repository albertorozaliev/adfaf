import React from 'react'
import GlassCard from '../components/GlassCard'
import { motion } from 'framer-motion'

export default function Overview() {
  return (
    <div className="space-y-6">
      <GlassCard className="flex items-center justify-between">
        <div>
          <div className="text-xl font-semibold">Overview</div>
          <div className="text-muted text-sm">Welcome to your dashboard</div>
        </div>
        <div className="text-xs glass rounded-full px-3 py-1">Coming Soon</div>
      </GlassCard>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <GlassCard className="p-8 text-center">
          <div className="text-lg font-medium mb-2">Overview Page</div>
          <div className="text-muted text-sm">This page is under development</div>
        </GlassCard>
      </motion.div>
    </div>
  )
}
