import React, { useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import GlassCard from '../components/GlassCard'
import AssignmentCard from '../components/AssignmentCard'
import CreateAssignmentModal from '../components/CreateAssignmentModal'
import EditAssignmentModal from '../components/EditAssignmentModal'
import ConfirmDeleteModal from '../components/ConfirmDeleteModal'
import EmailInviteModal from '../components/EmailInviteModal'
import EmailNotificationSender from '../components/EmailNotificationSender'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  BookOpen, 
  Rss, 
  Users, 
  Calendar, 
  Clock, 
  User, 
  MessageCircle,
  FileText,
  Image,
  Video,
  ArrowLeft,
  Plus,
  Edit,
  Trash2,
  Settings,
  MoreVertical,
  UserPlus,
  Palette
} from 'lucide-react'
import { useAssignments } from '../hooks/useAssignments'
import { useCourses } from '../hooks/useCourses'
import { useHistory } from '../hooks/useHistory'

const courses = {
  1: { title: 'Математика', teacher: 'Петров А.И.', color: 'linear-gradient(135deg,#1b8,#0af)' },
  2: { title: 'История', teacher: 'Волков Д.Н.', color: 'linear-gradient(135deg,#a0f,#f59)' },
  3: { title: 'Физика', teacher: 'Сидорова М.В.', color: 'linear-gradient(135deg,#0aa,#0f8)' },
  4: { title: 'Литература', teacher: 'Морозова О.С.', color: 'linear-gradient(135deg,#f70,#f39)' },
  5: { title: 'Биология', teacher: 'Николаева Е.А.', color: 'linear-gradient(135deg,#6cf,#49f)' },
  6: { title: 'Химия', teacher: 'Иванов С.П.', color: 'linear-gradient(135deg,#8b5cf6,#ec4899)' }
}



const courseAssignments = {
  1: [
    {
      id: 1,
      title: 'Глава 5: Квадратные уравнения',
      description: 'Выполните упражнения 1-20 из учебника. Покажите все решения и отправьте ваши ответы.',
      dueDate: '2025-12-15',
      completed: false,
      progress: 25,
      grade: null,
      maxGrade: 5
    },
    {
      id: 2,
      title: 'Подготовка к экзамену',
      description: 'Повторите главы 1-4 и выполните практические задачи. Экзамен будет охватывать весь материал.',
      dueDate: '2025-12-18',
      completed: true,
      progress: 100,
      grade: 5,
      maxGrade: 5
    },
    {
      id: 3,
      title: 'Групповой проект: Применение в реальном мире',
      description: 'Работайте с группой, чтобы найти реальные применения квадратных уравнений. Представьте ваши находки.',
      dueDate: '2025-12-22',
      completed: false,
      progress: 60,
      grade: null,
      maxGrade: 5
    }
  ],
  2: [
    {
      id: 1,
      title: 'Эссе: Реформы XIX века в России',
      description: 'Напишите анализ реформ Александра II и их влияния на развитие страны. Минимум 1500 слов.',
      dueDate: '2025-12-16',
      completed: false,
      progress: 40,
      grade: 4,
      maxGrade: 5
    },
    {
      id: 2,
      title: 'Презентация: Отечественная война 1812 года',
      description: 'Подготовьте презентацию о ключевых событиях и героях Отечественной войны.',
      dueDate: '2025-12-19',
      completed: false,
      progress: 80,
      grade: null,
      maxGrade: 5
    },
    {
      id: 3,
      title: 'Исследовательская работа: Культура России XIX века',
      description: 'Исследуйте развитие литературы, искусства и науки в России XIX века.',
      dueDate: '2025-12-25',
      completed: false,
      progress: 15,
      grade: null,
      maxGrade: 5
    }
  ],
  3: [
    {
      id: 1,
      title: 'Лабораторная работа: Механика',
      description: 'Проведите эксперимент по изучению движения тел под действием силы тяжести.',
      dueDate: '2025-12-14',
      completed: true,
      progress: 100,
      grade: 5,
      maxGrade: 5
    },
    {
      id: 2,
      title: 'Расчетная работа: Электричество',
      description: 'Решите задачи по электрическим цепям и закону Ома. Покажите все вычисления.',
      dueDate: '2025-12-17',
      completed: false,
      progress: 70,
      grade: null,
      maxGrade: 5
    },
    {
      id: 3,
      title: 'Проект: Создание простого двигателя',
      description: 'Создайте модель простого электродвигателя и объясните принцип его работы.',
      dueDate: '2025-12-23',
      completed: false,
      progress: 30,
      grade: null,
      maxGrade: 5
    }
  ],
  4: [
    {
      id: 1,
      title: 'Анализ "Евгения Онегина"',
      description: 'Напишите анализ главных тем и символов в романе А.С. Пушкина.',
      dueDate: '2025-12-15',
      completed: false,
      progress: 50
    },
    {
      id: 2,
      title: 'Стихотворение в стиле романтизма',
      description: 'Создайте собственное стихотворение, используя техники романтической поэзии XIX века.',
      dueDate: '2025-12-20',
      completed: false,
      progress: 20
    },
    {
      id: 3,
      title: 'Сравнительный анализ произведений',
      description: 'Сравните стили и темы двух русских авторов XIX века по вашему выбору.',
      dueDate: '2025-12-28',
      completed: false,
      progress: 0
    }
  ],
  5: [
    {
      id: 1,
      title: 'Лабораторная работа: Клеточная биология',
      description: 'Изучите строение клетки под микроскопом и зарисуйте основные органеллы.',
      dueDate: '2025-12-13',
      completed: true,
      progress: 100
    },
    {
      id: 2,
      title: 'Исследование: Генетика',
      description: 'Проведите исследование наследования признаков на примере гороха.',
      dueDate: '2025-12-18',
      completed: false,
      progress: 65
    },
    {
      id: 3,
      title: 'Презентация: Эволюция',
      description: 'Подготовьте презентацию о теории эволюции и доказательствах естественного отбора.',
      dueDate: '2025-12-24',
      completed: false,
      progress: 45
    }
  ],
  6: [
    {
      id: 1,
      title: 'Лабораторная работа: Органические соединения',
      description: 'Проведите эксперимент по изучению свойств органических соединений. Запишите наблюдения.',
      dueDate: '2025-12-16',
      completed: false,
      progress: 75
    },
    {
      id: 2,
      title: 'Расчетная работа: Химические реакции',
      description: 'Решите задачи по стехиометрии и химическим уравнениям. Покажите все вычисления.',
      dueDate: '2025-12-21',
      completed: false,
      progress: 35
    },
    {
      id: 3,
      title: 'Проект: Строение атома',
      description: 'Создайте модель атома и объясните принципы заполнения электронных оболочек.',
      dueDate: '2025-12-29',
      completed: false,
      progress: 10
    }
  ]
}

const courseStreamPosts = {
  1: [
    {
      id: 1,
      author: 'Петров А.И.',
      content: 'Добро пожаловать в курс математики! Начинаем изучение алгебры и геометрии. Изучите программу курса.',
      timestamp: '2 часа назад',
      type: 'announcement'
    },
    {
      id: 2,
      author: 'Алексей Смирнов',
      content: 'Нашел отличное видео по решению квадратных уравнений. Очень помогает понять материал!',
      timestamp: '4 часа назад',
      type: 'resource',
      attachment: 'https://youtube.com/watch?v=example'
    },
    {
      id: 3,
      author: 'Софья Козлова',
      content: 'Кто хочет создать группу для подготовки к контрольной работе?',
      timestamp: '1 день назад',
      type: 'discussion'
    }
  ],
  2: [
    {
      id: 1,
      author: 'Волков Д.Н.',
      content: 'Начинаем изучение истории России XIX века. Обратите внимание на реформы Александра II.',
      timestamp: '1 час назад',
      type: 'announcement'
    },
    {
      id: 2,
      author: 'Михаил Волков',
      content: 'Интересная статья о влиянии отмены крепостного права на развитие страны.',
      timestamp: '3 часа назад',
      type: 'resource',
      attachment: 'https://example.com/article'
    }
  ],
  3: [
    {
      id: 1,
      author: 'Сидорова М.В.',
      content: 'Лабораторная работа по механике перенесена на следующую неделю. Приносите калькуляторы!',
      timestamp: '30 минут назад',
      type: 'announcement'
    },
    {
      id: 2,
      author: 'Дмитрий Новиков',
      content: 'Нашел симулятор электрических цепей для практики. Очень полезно!',
      timestamp: '2 часа назад',
      type: 'resource',
      attachment: 'https://phet.colorado.edu'
    }
  ],
  4: [
    {
      id: 1,
      author: 'Морозова О.С.',
      content: 'Начинаем изучение русской литературы XIX века. Прочитайте "Евгений Онегин" Пушкина к следующему занятию.',
      timestamp: '1 час назад',
      type: 'announcement'
    },
    {
      id: 2,
      author: 'Елена Соколова',
      content: 'Поделюсь анализом символики в "Войне и мире" Толстого. Может быть полезно для сочинения.',
      timestamp: '5 часов назад',
      type: 'discussion'
    }
  ],
  5: [
    {
      id: 1,
      author: 'Николаева Е.А.',
      content: 'Экскурсия в лабораторию генетики состоится в пятницу. Записывайтесь!',
      timestamp: '2 часа назад',
      type: 'announcement'
    },
    {
      id: 2,
      author: 'Софья Козлова',
      content: 'Отличное видео о структуре ДНК и процессе репликации.',
      timestamp: '1 день назад',
      type: 'resource',
      attachment: 'https://youtube.com/watch?v=dna'
    }
  ],
  6: [
    {
      id: 1,
      author: 'Иванов С.П.',
      content: 'Лабораторная работа по органической химии состоится в среду. Приносите халаты и защитные очки!',
      timestamp: '3 часа назад',
      type: 'announcement'
    },
    {
      id: 2,
      author: 'Алексей Смирнов',
      content: 'Нашел отличное видео по строению атома и химическим связям. Очень наглядно объясняет!',
      timestamp: '6 часов назад',
      type: 'discussion'
    }
  ]
}

const coursePeople = {
  1: [
    { id: 1, name: 'Петров А.И.', role: 'Учитель', avatar: '👨‍🏫' },
    { id: 2, name: 'Алексей Смирнов', role: 'Студент', avatar: '👨‍🎓' },
    { id: 3, name: 'Софья Козлова', role: 'Студент', avatar: '👩‍🎓' },
    { id: 4, name: 'Михаил Волков', role: 'Студент', avatar: '👨‍🎓' },
    { id: 5, name: 'Елена Соколова', role: 'Студент', avatar: '👩‍🎓' },
    { id: 6, name: 'Дмитрий Новиков', role: 'Студент', avatar: '👨‍🎓' }
  ],
  2: [
    { id: 1, name: 'Волков Д.Н.', role: 'Учитель', avatar: '👨‍🏫' },
    { id: 2, name: 'Анна Кузнецова', role: 'Студент', avatar: '👩‍🎓' },
    { id: 3, name: 'Игорь Петров', role: 'Студент', avatar: '👨‍🎓' },
    { id: 4, name: 'Мария Иванова', role: 'Студент', avatar: '👩‍🎓' },
    { id: 5, name: 'Сергей Смирнов', role: 'Студент', avatar: '👨‍🎓' },
    { id: 6, name: 'Ольга Васильева', role: 'Студент', avatar: '👩‍🎓' }
  ],
  3: [
    { id: 1, name: 'Сидорова М.В.', role: 'Учитель', avatar: '👩‍🏫' },
    { id: 2, name: 'Андрей Козлов', role: 'Студент', avatar: '👨‍🎓' },
    { id: 3, name: 'Наталья Морозова', role: 'Студент', avatar: '👩‍🎓' },
    { id: 4, name: 'Павел Соколов', role: 'Студент', avatar: '👨‍🎓' },
    { id: 5, name: 'Екатерина Новикова', role: 'Студент', avatar: '👩‍🎓' },
    { id: 6, name: 'Артем Волков', role: 'Студент', avatar: '👨‍🎓' }
  ],
  4: [
    { id: 1, name: 'Морозова О.С.', role: 'Учитель', avatar: '👩‍🏫' },
    { id: 2, name: 'Денис Кузнецов', role: 'Студент', avatar: '👨‍🎓' },
    { id: 3, name: 'Алина Петрова', role: 'Студент', avatar: '👩‍🎓' },
    { id: 4, name: 'Максим Иванов', role: 'Студент', avatar: '👨‍🎓' },
    { id: 5, name: 'Виктория Смирнова', role: 'Студент', avatar: '👩‍🎓' },
    { id: 6, name: 'Роман Козлов', role: 'Студент', avatar: '👨‍🎓' }
  ],
  5: [
    { id: 1, name: 'Николаева Е.А.', role: 'Учитель', avatar: '👩‍🏫' },
    { id: 2, name: 'Юлия Морозова', role: 'Студент', avatar: '👩‍🎓' },
    { id: 3, name: 'Антон Соколов', role: 'Студент', avatar: '👨‍🎓' },
    { id: 4, name: 'Татьяна Новикова', role: 'Студент', avatar: '👩‍🎓' },
    { id: 5, name: 'Владимир Волков', role: 'Студент', avatar: '👨‍🎓' },
    { id: 6, name: 'Елена Кузнецова', role: 'Студент', avatar: '👩‍🎓' }
  ],
  6: [
    { id: 1, name: 'Иванов С.П.', role: 'Учитель', avatar: '👨‍🏫' },
    { id: 2, name: 'Артем Смирнов', role: 'Студент', avatar: '👨‍🎓' },
    { id: 3, name: 'Анна Петрова', role: 'Студент', avatar: '👩‍🎓' },
    { id: 4, name: 'Дмитрий Иванов', role: 'Студент', avatar: '👨‍🎓' },
    { id: 5, name: 'Мария Козлова', role: 'Студент', avatar: '👩‍🎓' },
    { id: 6, name: 'Сергей Новиков', role: 'Студент', avatar: '👨‍🎓' }
  ]
}

const colorOptions = [
  { value: 'linear-gradient(135deg,#1b8,#0af)', label: 'Синий' },
  { value: 'linear-gradient(135deg,#a0f,#f59)', label: 'Фиолетовый' },
  { value: 'linear-gradient(135deg,#0aa,#0f8)', label: 'Зеленый' },
  { value: 'linear-gradient(135deg,#f70,#f39)', label: 'Оранжевый' },
  { value: 'linear-gradient(135deg,#6cf,#49f)', label: 'Голубой' },
  { value: 'linear-gradient(135deg,#8b5cf6,#ec4899)', label: 'Розовый' }
]

const TabButton = ({ icon: Icon, label, active, onClick }) => (
  <button
    onClick={onClick}
    className={`flex items-center gap-2 px-4 py-2 rounded-2xl transition-colors ${
      active ? 'glass ring-1 ring-white/20 bg-white/10' : 'hover:bg-white/5'
    }`}
  >
    <Icon size={18} />
    <span className="text-sm">{label}</span>
  </button>
)

const StudentActionsModal = ({ isOpen, onClose, student, onMessage, onRemove }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <GlassCard className="p-6 rounded-2xl max-w-sm w-full">
        <h3 className="text-lg font-semibold mb-4">Действия для {student.name}</h3>
        <div className="space-y-3">
          <button 
            onClick={() => { onMessage(student); onClose(); }}
            className="w-full glass rounded-xl p-3 hover:bg-white/10 transition-colors text-left"
          >
            Написать ученику
          </button>
          <button 
            onClick={() => { onRemove(student.id); onClose(); }}
            className="w-full glass rounded-xl p-3 hover:bg-red-500/20 transition-colors text-left text-red-400"
          >
            Удалить с курса
          </button>
          <button 
            onClick={onClose}
            className="w-full glass rounded-xl p-3 hover:bg-white/10 transition-colors text-left"
          >
            Отмена
          </button>
        </div>
      </GlassCard>
    </div>
  );
};

const CourseActionsModal = ({ isOpen, onClose, onEdit, onDelete }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <GlassCard className="p-4 rounded-2xl max-w-xs w-full">
        <div className="space-y-2">
          <button 
            onClick={() => { onEdit(); onClose(); }}
            className="w-full glass rounded-xl p-3 hover:bg-white/10 transition-colors text-left"
          >
            Изменить данные о курсе
          </button>
          <button 
            onClick={() => { onDelete(); onClose(); }}
            className="w-full glass rounded-xl p-3 hover:bg-red-500/20 transition-colors text-left text-red-400"
          >
            Удалить курс
          </button>
          <button 
            onClick={onClose}
            className="w-full glass rounded-xl p-3 hover:bg-white/10 transition-colors text-left"
          >
            Отмена
          </button>
        </div>
      </GlassCard>
    </div>
  );
};

const EditCourseModal = ({ isOpen, onClose, onSave, course }) => {
  const [title, setTitle] = useState(course?.title || '')
  const [color, setColor] = useState(course?.color || colorOptions[0].value)

  if (!isOpen) return null;

  const handleSubmit = () => {
    if (!title.trim()) {
      alert('Название курса не может быть пустым')
      return
    }
    onSave({ title, color })
    onClose()
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <GlassCard className="p-6 rounded-2xl max-w-md w-full">
        <h3 className="text-lg font-semibold mb-4">Редактировать курс</h3>
        <div className="space-y-4">
          <div>
            <label className="text-sm text-muted block mb-1">Название курса</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Введите название курса"
              className="input glass px-3 py-2 rounded w-full"
            />
          </div>
          <div>
            <label className="text-sm text-muted block mb-1">Цвет курса</label>
            <select
              value={color}
              onChange={(e) => setColor(e.target.value)}
              className="input glass px-3 py-2 rounded w-full"
            >
              {colorOptions.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>
          <div className="flex gap-4">
            <button
              onClick={onClose}
              className="flex-1 glass rounded-xl p-3 hover:bg-white/10 transition-colors"
            >
              Отмена
            </button>
            <button
              onClick={handleSubmit}
              className="flex-1 bg-blue-500 text-white rounded-xl p-3 hover:bg-blue-600 transition-colors"
            >
              Сохранить
            </button>
          </div>
        </div>
      </GlassCard>
    </div>
  );
};

export default function CourseDetail() {
  const { id } = useParams()
  const navigate = useNavigate()
  const [activeTab, setActiveTab] = useState('assignments')
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false)
  const [isEditModalOpen, setIsEditModalOpen] = useState(false)
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false)
  const [isCourseActionsOpen, setIsCourseActionsOpen] = useState(false)
  const [isInviteModalOpen, setIsInviteModalOpen] = useState(false)
  const [isNotificationModalOpen, setIsNotificationModalOpen] = useState(false)
  const [isEditCourseModalOpen, setIsEditCourseModalOpen] = useState(false)
  const [selectedAssignment, setSelectedAssignment] = useState(null)
  const [isStudentActionsOpen, setIsStudentActionsOpen] = useState(false)
  const [selectedStudent, setSelectedStudent] = useState(null)
  const { assignments, addAssignment, updateAssignment } = useAssignments()
  const { getCourse, deleteCourse, updateCourse } = useCourses()
  const { addAssignmentCreated } = useHistory()
  
  const dynamicCourse = getCourse(id)
  const course = dynamicCourse || courses[id]
  
  if (!course) {
    return <div>Course not found</div>
  }

  const getLegacyId = (course) => {
    if (!course) return id
    
    if (['1', '2', '3', '4', '5', '6'].includes(id)) return id
    
    const legacyMapping = {
      'Математика': '1',
      'История': '2',
      'Физика': '3',
      'Литература': '4',
      'Биология': '5',
      'Химия': '6'
    }
    
    return legacyMapping[course.title] || '1' 
  }

  const legacyId = getLegacyId(course)

  const [localPeople, setLocalPeople] = useState(() => {
    let people = coursePeople[legacyId] || []
    
    if (people.length === 0 && course) {
      people = [
        { id: 1, name: course.teacher, role: 'Учитель', avatar: '👩‍🏫' },
        { id: 2, name: 'Александр Иванов', role: 'Студент', avatar: '👨‍🎓' },
        { id: 3, name: 'Мария Петрова', role: 'Студент', avatar: '👩‍🎓' },
        { id: 4, name: 'Дмитрий Сидоров', role: 'Студент', avatar: '👨‍🎓' },
        { id: 5, name: 'Елена Козлова', role: 'Студент', avatar: '👩‍🎓' },
        { id: 6, name: 'Андрей Морозов', role: 'Студент', avatar: '👨‍🎓' }
      ]
    }
    return people
  })

  const handleCreateAssignment = (newAssignment) => {
    const assignmentWithCourse = {
      ...newAssignment,
      course: course.title,
      teacher: course.teacher
    }
    const createdAssignment = addAssignment(assignmentWithCourse)
    
    addAssignmentCreated(createdAssignment, course)
  }

  const handleEditAssignment = (assignment) => {
    setSelectedAssignment(assignment)
    setIsEditModalOpen(true)
  }

  const handleSaveEdit = (updatedAssignment) => {
    updateAssignment(updatedAssignment.id, updatedAssignment)
    setIsEditModalOpen(false)
    setSelectedAssignment(null)
  }

  const handleMessageStudent = (student) => {
    setSelectedStudent(student)
    setIsNotificationModalOpen(true)
  }

  const handleRemoveStudent = (studentId) => {
    setLocalPeople(prev => prev.filter(person => person.id !== studentId))
  }

  const handleInvite = (emails) => {
    const newStudents = emails.map((email, index) => ({
      id: Math.max(...localPeople.map(p => p.id), 0) + index + 1,
      name: email.split('@')[0], // Simplified name generation from email
      role: 'Студент',
      avatar: '👨‍🎓'
    }))
    setLocalPeople(prev => [...prev, ...newStudents])
    setIsInviteModalOpen(false)
    setIsNotificationModalOpen(true)
    return { emails, message: `Вы приглашены на курс "${course.title}"! Пожалуйста, зарегистрируйтесь для участия.` }
  }

  const handleSendNotification = ({ emails, message }) => {
    console.log(`Отправка уведомлений на: ${emails.join(', ')} с сообщением: ${message}`)
    // Here you would typically call an API to send the emails
  }

  const handleEditCourse = () => {
    setIsEditCourseModalOpen(true)
  }

  const handleSaveCourse = (updatedCourse) => {
    updateCourse(id, { ...course, ...updatedCourse })
  }

  const renderAssignments = () => {
    const courseAssignments = Object.values(assignments).filter(
      assignment => assignment.course === course.title
    )
    
    return (
      <motion.div
        key="assignments"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        className="space-y-6"
      >
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold">Задания</h3>
            <p className="text-sm text-muted">{courseAssignments.length} заданий</p>
          </div>
          <button
            onClick={() => setIsCreateModalOpen(true)}
            className="glass rounded-xl px-4 py-2 hover:bg-white/10 transition-colors flex items-center gap-2"
          >
            <Plus size={16} />
            Создать задание
          </button>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-2 gap-4 lg:gap-6">
          {courseAssignments.map((assignment) => (
            <div key={assignment.id} className="relative group">
              <AssignmentCard
                {...assignment}
                course={course.title}
                teacher={course.teacher}
                courseId={id}
                assignmentId={assignment.id}
                lastModified={assignment.lastModified}
                onClick={() => navigate(`/course/${id}/assignment/${assignment.id}`)}
              />
              <button
                onClick={(e) => {
                  e.stopPropagation()
                  handleEditAssignment(assignment)
                }}
                className="absolute top-2 right-2 glass rounded-full p-2 hover:bg-white/10 transition-colors opacity-0 group-hover:opacity-100"
                title="Редактировать задание"
              >
                <Edit size={14} />
              </button>
            </div>
          ))}
        </div>
      </motion.div>
    )
  }

  const renderStream = () => {
    let streamPosts = courseStreamPosts[legacyId] || []
    
    if (streamPosts.length === 0 && course) {
      streamPosts = [
        {
          id: 1,
          author: course.teacher,
          content: `Добро пожаловать в курс "${course.title}"! Здесь будут размещаться объявления и материалы курса.`,
          timestamp: '1 день назад',
          type: 'announcement'
        },
        {
          id: 2,
          author: course.teacher,
          content: 'Ознакомьтесь с программой курса и задавайте вопросы, если что-то непонятно.',
          timestamp: '2 дня назад',
          type: 'announcement'
        }
      ]
    }
    return (
      <motion.div
        key="stream"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        className="space-y-4"
      >
        {streamPosts.map((post) => (
          <GlassCard key={post.id} className="p-6">
            <div className="flex items-start gap-4">
              <div className="glass rounded-full p-2 flex-shrink-0">
                {post.type === 'announcement' && <MessageCircle size={16} />}
                {post.type === 'resource' && <FileText size={16} />}
                {post.type === 'discussion' && <Users size={16} />}
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <span className="font-medium text-sm">{post.author}</span>
                  <span className="text-xs text-muted">{post.timestamp}</span>
                  <span className={`text-xs glass rounded-full px-2 py-1 ${
                    post.type === 'announcement' ? 'bg-blue-500/20 text-blue-400' :
                    post.type === 'resource' ? 'bg-green-500/20 text-green-400' :
                    'bg-purple-500/20 text-purple-400'
                  }`}>
                    {post.type === 'announcement' ? 'Объявление' :
                     post.type === 'resource' ? 'Ресурс' : 'Обсуждение'}
                  </span>
                </div>
                <p className="text-sm text-muted mb-3">{post.content}</p>
                {post.attachment && (
                  <div className="glass rounded-2xl p-3 text-sm">
                    <a href={post.attachment} className="text-blue-400 hover:underline">
                      📎 Посмотреть вложение
                    </a>
                  </div>
                )}
              </div>
            </div>
          </GlassCard>
        ))}
      </motion.div>
    )
  }

  const renderPeople = () => {
    const teachers = localPeople.filter(person => person.role === 'Учитель')
    const students = localPeople.filter(person => person.role === 'Студент')

    return (
      <motion.div
        key="people"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        className="space-y-8"
      >
        <div>
          <h3 className="text-lg font-semibold mb-4 text-blue-400">Преподаватели ({teachers.length})</h3>
          <div className="space-y-4">
            {teachers.length > 0 ? (
              teachers.map((person) => (
                <GlassCard key={person.id} className="p-4 hover:bg-white/5 transition-colors cursor-pointer">
                  <div className="flex items-center gap-4">
                    <div className="text-2xl">{person.avatar}</div>
                    <div className="flex-1">
                      <div className="font-medium">{person.name}</div>
                      <div className="text-sm text-muted">{person.role}</div>
                    </div>
                    <div className={`text-xs glass rounded-full px-3 py-1 bg-blue-500/20 text-blue-400`}>
                      {person.role}
                    </div>
                  </div>
                </GlassCard>
              ))
            ) : (
              <p className="text-muted">Нет преподавателей</p>
            )}
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-green-400">Учащиеся ({students.length})</h3>
            <button
              onClick={() => setIsInviteModalOpen(true)}
              className="glass rounded-xl px-4 py-2 hover:bg-white/10 transition-colors flex items-center gap-2"
            >
              <UserPlus size={16} />
              Пригласить ученика
            </button>
          </div>
          <div className="space-y-4">
            {students.length > 0 ? (
              students.map((person) => (
                <GlassCard key={person.id} className="p-4 hover:bg-white/5 transition-colors cursor-pointer relative group">
                  <div className="flex items-center gap-4">
                    <div className="text-2xl">{person.avatar}</div>
                    <div className="flex-1">
                      <div className="font-medium">{person.name}</div>
                      <div className="text-sm text-muted">{person.role}</div>
                    </div>
                    <div className={`text-xs glass rounded-full px-3 py-1 bg-green-500/20 text-green-400 transition-all duration-200 group-hover:mr-8`}>
                      {person.role}
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      setSelectedStudent(person)
                      setIsStudentActionsOpen(true)
                    }}
                    className="absolute top-1/2 right-2 transform -translate-y-1/2 glass rounded-full p-2 hover:bg-white/10 transition-colors opacity-0 group-hover:opacity-100"
                    title="Действия"
                  >
                    <Settings size={16} />
                  </button>
                </GlassCard>
              ))
            ) : (
              <p className="text-muted">Нет учащихся</p>
            )}
          </div>
        </div>
      </motion.div>
    )
  }

  return (
    <div className="space-y-6 content-scroll">
      <GlassCard className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate('/my-courses')}
            className="glass rounded-full p-2 hover:bg-white/10 transition-colors"
          >
            <ArrowLeft size={18} />
          </button>
          <div>
            <div className="text-xl font-semibold">{course.title}</div>
            <div className="text-muted text-sm">Teacher: {course.teacher}</div>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-xs glass rounded-full px-3 py-1">Active</div>
          <button
            onClick={() => setIsCourseActionsOpen(true)}
            className="glass rounded-full p-2 hover:bg-white/10 transition-colors"
            title="Действия с курсом"
          >
            <MoreVertical size={18} className="text-white" />
          </button>
        </div>
      </GlassCard>

      <div className="flex gap-2">
        <TabButton
          icon={BookOpen}
          label="Задания"
          active={activeTab === 'assignments'}
          onClick={() => setActiveTab('assignments')}
        />
        <TabButton
          icon={Rss}
          label="Лента"
          active={activeTab === 'stream'}
          onClick={() => setActiveTab('stream')}
        />
        <TabButton
          icon={Users}
          label="Участники"
          active={activeTab === 'people'}
          onClick={() => setActiveTab('people')}
        />
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'assignments' && renderAssignments()}
        {activeTab === 'stream' && renderStream()}
        {activeTab === 'people' && renderPeople()}
      </AnimatePresence>

      <CreateAssignmentModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        onCreate={handleCreateAssignment}
        courseData={course}
      />

      <EditAssignmentModal
        isOpen={isEditModalOpen}
        onClose={() => {
          setIsEditModalOpen(false)
          setSelectedAssignment(null)
        }}
        onSave={handleSaveEdit}
        assignment={selectedAssignment}
      />

      <ConfirmDeleteModal
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        onConfirm={() => {
          deleteCourse(id)
          navigate('/my-courses')
        }}
        title="Удалить курс"
        message={`Вы уверены, что хотите удалить курс "${course.title}"? Это действие нельзя отменить, и все задания и материалы курса будут потеряны.`}
        confirmText="Удалить курс"
        cancelText="Отмена"
        type="danger"
      />

      <StudentActionsModal
        isOpen={isStudentActionsOpen}
        onClose={() => {
          setIsStudentActionsOpen(false)
          setSelectedStudent(null)
        }}
        student={selectedStudent}
        onMessage={handleMessageStudent}
        onRemove={handleRemoveStudent}
      />

      <CourseActionsModal
        isOpen={isCourseActionsOpen}
        onClose={() => setIsCourseActionsOpen(false)}
        onEdit={handleEditCourse}
        onDelete={() => setIsDeleteModalOpen(true)}
      />

      <EditCourseModal
        isOpen={isEditCourseModalOpen}
        onClose={() => setIsEditCourseModalOpen(false)}
        onSave={handleSaveCourse}
        course={course}
      />

      <EmailInviteModal
        isOpen={isInviteModalOpen}
        onClose={() => setIsInviteModalOpen(false)}
        onInvite={handleInvite}
      />

      <EmailNotificationSender
        isOpen={isNotificationModalOpen}
        onClose={() => setIsNotificationModalOpen(false)}
        onSend={handleSendNotification}
      />
    </div>
  )
}