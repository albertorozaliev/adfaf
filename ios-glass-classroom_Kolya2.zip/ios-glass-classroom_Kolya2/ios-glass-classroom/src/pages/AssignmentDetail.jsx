import React, { useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { ArrowLeft, FileText, Link, Upload, Calendar, User, BookOpen, Trash2, Edit, Clock, Star } from 'lucide-react'
import GlassCard from '../components/GlassCard'
import AttachmentModal from '../components/AttachmentModal'
import GradeModal from '../components/GradeModal'
import EditAssignmentModal from '../components/EditAssignmentModal'
import NotificationToast from '../components/NotificationToast'
import { useAttachments } from '../hooks/useAttachments'
import { useGrades } from '../hooks/useGrades'
import { useAssignments } from '../hooks/useAssignments'



export default function AssignmentDetail() {
  const { courseId, assignmentId } = useParams()
  const navigate = useNavigate()
  const [isAttachmentModalOpen, setIsAttachmentModalOpen] = useState(false)
  const [isGradeModalOpen, setIsGradeModalOpen] = useState(false)
  const [isEditModalOpen, setIsEditModalOpen] = useState(false)
  const { getAssignment, updateAssignment } = useAssignments()
  const [notification, setNotification] = useState({ isVisible: false, type: 'success', title: '', message: '', attachments: [] })
  const { attachments, addAttachments, removeAttachment } = useAttachments(assignmentId)
  const { grade, updateGrade } = useGrades(assignmentId)

  const assignment = getAssignment(parseInt(assignmentId))
  
  if (!assignment) {
    return <div>Задание не найдено</div>
  }

  const handleAttach = (newAttachments) => {
    addAttachments(newAttachments)
    
    // Подготавливаем данные для уведомления
    const formattedAttachments = []
    
    newAttachments.files.forEach(file => {
      formattedAttachments.push({
        type: 'file',
        name: file.name
      })
    })
    
    newAttachments.links.forEach(link => {
      if (link.trim()) {
        formattedAttachments.push({
          type: 'link',
          name: link
        })
      }
    })
    
    newAttachments.driveFiles.forEach(file => {
      formattedAttachments.push({
        type: 'drive',
        name: file.name
      })
    })
    
    // Показываем уведомление
    setNotification({
      isVisible: true,
      type: 'upload',
      title: 'Файлы прикреплены!',
      message: `Успешно прикреплено ${formattedAttachments.length} файлов к заданию`,
      attachments: formattedAttachments
    })
    
    // Автоматически скрываем уведомление через 5 секунд
    setTimeout(() => {
      setNotification(prev => ({ ...prev, isVisible: false }))
    }, 5000)
  }

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('ru-RU', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    })
  }

  const formatDateTime = (dateString) => {
    return new Date(dateString).toLocaleString('ru-RU', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const handleEditAssignment = (updatedAssignment) => {
    updateAssignment(assignment.id, updatedAssignment)
    
    setNotification({
      isVisible: true,
      type: 'success',
      title: 'Задание обновлено!',
      message: 'Изменения сохранены успешно',
      attachments: []
    })
    
    setTimeout(() => {
      setNotification(prev => ({ ...prev, isVisible: false }))
    }, 3000)
  }

  const getProgressColor = (progress) => {
    if (progress >= 100) return 'bg-green-500'
    if (progress >= 70) return 'bg-blue-500'
    if (progress >= 40) return 'bg-yellow-500'
    return 'bg-red-500'
  }

  return (
    <div className="space-y-6 content-scroll">
      {/* Header */}
      <GlassCard className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate(`/course/${courseId}`)}
            className="glass rounded-full p-2 hover:bg-white/10 transition-colors"
          >
            <ArrowLeft size={18} />
          </button>
                     <div>
             <div className="text-xl font-semibold">{assignment.title}</div>
             <div className="text-muted text-sm">{assignment.course} • {assignment.teacher}</div>
             {assignment.lastModified && (
               <div className="text-xs text-muted mt-1 flex items-center gap-1">
                 <Clock size={12} />
                 Изменено: {formatDateTime(assignment.lastModified)}
               </div>
             )}
           </div>
        </div>
                 <div className="flex items-center gap-3">
           <div className="text-xs glass rounded-full px-3 py-1">
             Прогресс: {assignment.progress}%
           </div>
                       {(assignment.grade !== null || grade !== null) && (
              <div className="text-xs glass rounded-full px-3 py-1 bg-green-500/20 text-green-400">
                {grade || assignment.grade}/{assignment.maxGrade}
              </div>
            )}
           <div className={`w-2 h-2 rounded-full ${getProgressColor(assignment.progress)}`}></div>
         </div>
      </GlassCard>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Основная информация */}
        <div className="lg:col-span-2 space-y-6">
          {/* Описание */}
          <GlassCard className="p-6">
            <div className="flex items-center gap-3 mb-4">
              <BookOpen size={20} />
              <h3 className="text-lg font-semibold">Описание задания</h3>
            </div>
            <div className="prose prose-invert max-w-none">
              {assignment.description.split('\n').map((paragraph, index) => (
                <p key={index} className="text-sm text-muted mb-3">
                  {paragraph}
                </p>
              ))}
            </div>
          </GlassCard>

                     {/* Прикрепленные файлы */}
           {attachments.length > 0 && (
            <GlassCard className="p-6">
              <div className="flex items-center gap-3 mb-4">
                <FileText size={20} />
                <h3 className="text-lg font-semibold">Прикрепленные файлы</h3>
              </div>
                             <div className="space-y-3">
                 {attachments.map((attachment, index) => (
                                        <div key={attachment.id} className="glass rounded-xl p-3 flex items-center justify-between">
                       <div className="flex items-center gap-3">
                         {attachment.type === 'link' ? (
                           <>
                             <Link size={16} />
                             <div>
                               <div className="text-sm font-medium">{attachment.name}</div>
                               <div className="text-xs text-muted">Ссылка</div>
                             </div>
                           </>
                         ) : (
                           <>
                             <FileText size={16} />
                             <div>
                               <div className="text-sm font-medium">{attachment.name}</div>
                               <div className="text-xs text-muted">{attachment.size}</div>
                             </div>
                           </>
                         )}
                       </div>
                       <div className="flex items-center gap-2">
                         <a
                           href={attachment.url}
                           target="_blank"
                           rel="noopener noreferrer"
                           className="text-blue-400 hover:underline text-sm"
                         >
                           Открыть
                         </a>
                         <button
                           onClick={() => removeAttachment(attachment.id)}
                           className="glass rounded-full p-1 hover:bg-red-500/20 transition-colors"
                         >
                           <Trash2 size={14} className="text-red-400" />
                         </button>
                       </div>
                     </div>
                 ))}
               </div>
            </GlassCard>
          )}
        </div>

        {/* Боковая панель */}
        <div className="space-y-6">
          {/* Информация о задании */}
          <GlassCard className="p-6">
            <h3 className="text-lg font-semibold mb-4">Информация</h3>
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <Calendar size={16} className="text-muted" />
                <div>
                  <div className="text-sm font-medium">Срок сдачи</div>
                  <div className="text-xs text-muted">{formatDate(assignment.dueDate)}</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <User size={16} className="text-muted" />
                <div>
                  <div className="text-sm font-medium">Преподаватель</div>
                  <div className="text-xs text-muted">{assignment.teacher}</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <BookOpen size={16} className="text-muted" />
                <div>
                  <div className="text-sm font-medium">Курс</div>
                  <div className="text-xs text-muted">{assignment.course}</div>
                </div>
              </div>
            </div>
          </GlassCard>

                     {/* Прогресс */}
           <GlassCard className="p-6">
             <h3 className="text-lg font-semibold mb-4">Прогресс</h3>
             <div className="space-y-3">
               <div className="flex justify-between text-sm">
                 <span>Выполнение</span>
                 <span>{assignment.progress}%</span>
               </div>
               <div className="w-full bg-white/10 rounded-full h-2">
                 <div
                   className={`h-2 rounded-full ${getProgressColor(assignment.progress)} transition-all duration-300`}
                   style={{ width: `${assignment.progress}%` }}
                 ></div>
               </div>
               <div className="text-xs text-muted">
                 {assignment.progress === 100 ? 'Задание выполнено' : 'Работа в процессе'}
               </div>
             </div>
           </GlassCard>

                                               {/* Оценка */}
             <GlassCard className="p-6">
               <div className="flex items-center justify-between mb-4">
                 <h3 className="text-lg font-semibold">Оценка</h3>
                 <button
                   onClick={() => navigate(`/course/${courseId}/assignment/${assignmentId}/grades`)}
                   className="glass rounded-lg px-3 py-1.5 text-sm font-medium transition-colors flex items-center gap-2 bg-yellow-500/20 text-yellow-400 hover:bg-yellow-500/30"
                 >
                   <Star size={14} />
                   Оценки
                 </button>
               </div>
               <div className="space-y-3">
                 {(assignment.grade !== null || grade !== null) ? (
                   <>
                     <div className="flex justify-between text-sm">
                       <span>Получено</span>
                       <span className="font-semibold text-green-400">{grade || assignment.grade}/{assignment.maxGrade}</span>
                     </div>
                     <div className="w-full bg-white/10 rounded-full h-2">
                       <div
                         className="h-2 rounded-full bg-green-500 transition-all duration-300"
                         style={{ width: `${((grade || assignment.grade) / assignment.maxGrade) * 100}%` }}
                       ></div>
                     </div>
                     <div className="text-xs text-muted">
                       {(grade || assignment.grade) === 5 ? 'Отлично!' :
                        (grade || assignment.grade) === 4 ? 'Хорошо' :
                        (grade || assignment.grade) === 3 ? 'Удовлетворительно' :
                        (grade || assignment.grade) === 2 ? 'Неудовлетворительно' : 'Плохо'}
                     </div>
                   </>
                 ) : (
                   <div className="text-center py-4">
                     <div className="text-sm text-muted">Оценка еще не выставлена</div>
                     <div className="text-xs text-muted mt-1">Преподаватель проверит работу</div>
                   </div>
                 )}
               </div>
             </GlassCard>

                                           {/* Действия */}
            <GlassCard className="p-6">
              <h3 className="text-lg font-semibold mb-4">Действия</h3>
              <div className="space-y-3">
                <button
                  onClick={() => setIsEditModalOpen(true)}
                  className="w-full glass rounded-xl px-4 py-3 hover:bg-white/10 transition-colors flex items-center gap-2"
                >
                  <Edit size={16} />
                  Редактировать задание
                </button>
                <button
                  onClick={() => setIsAttachmentModalOpen(true)}
                  className="w-full glass rounded-xl px-4 py-3 hover:bg-white/10 transition-colors flex items-center gap-2"
                >
                  <Upload size={16} />
                  Прикрепить работу
                </button>
                <button
                  onClick={() => alert('Функция просмотра в разработке')}
                  className="w-full glass rounded-xl px-4 py-3 hover:bg-white/10 transition-colors flex items-center gap-2"
                >
                  <FileText size={16} />
                  Просмотреть работу
                </button>
                
                <button
                   onClick={() => setIsGradeModalOpen(true)}
                   className="w-full glass rounded-xl px-4 py-3 hover:bg-white/10 transition-colors flex items-center gap-2"
                 >
                   <FileText size={16} />
                   Изменить оценку
                 </button>
              </div>
            </GlassCard>
        </div>
      </div>

                           {/* Модальные окна */}
        <AttachmentModal
          isOpen={isAttachmentModalOpen}
          onClose={() => setIsAttachmentModalOpen(false)}
          onAttach={handleAttach}
        />
        
        <GradeModal
          isOpen={isGradeModalOpen}
          onClose={() => setIsGradeModalOpen(false)}
          onSave={updateGrade}
          currentGrade={grade || assignment.grade}
          maxGrade={assignment.maxGrade}
        />

        <EditAssignmentModal
          isOpen={isEditModalOpen}
          onClose={() => setIsEditModalOpen(false)}
          onSave={handleEditAssignment}
          assignment={assignment}
        />
       
       {/* Уведомления */}
       <NotificationToast
         isVisible={notification.isVisible}
         onClose={() => setNotification(prev => ({ ...prev, isVisible: false }))}
         type={notification.type}
         title={notification.title}
         message={notification.message}
         attachments={notification.attachments}
       />
     </div>
   )
 }
