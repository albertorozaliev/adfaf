import React from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import GlassCard from '../components/GlassCard'
import { signIn } from '../lib/auth'

export default function SignIn() {
  const nav = useNavigate()
  const [error, setError] = React.useState('')

  function onSubmit(e) {
    e.preventDefault()
    const email = e.target.email.value.trim()
    const password = e.target.password.value.trim()
    try {
      signIn({ email, password })
      nav('/courses')
    } catch (err) {
      setError(err.message)
    }
  }

  return (
    <div className="min-h-screen text-ink flex items-center justify-center relative">
      <motion.div className="fixed inset-0 -z-10 bg-mesh" initial={{ opacity: 0 }} animate={{ opacity: 1 }} />
      <div className="fixed -z-10 w-[90vmin] h-[90vmin] rounded-full blur-3xl opacity-20 left-1/2 -translate-x-1/2 -top-32"
           style={{ background: 'var(--gradient-1)' }} />
      <GlassCard className="w-[min(420px,94vw)] p-8 rounded-3xl">
        <div className="text-center mb-6">
          <div className="w-14 h-14 mx-auto rounded-2xl bg-white/10 backdrop-blur grid place-items-center mb-3">
            <div className="w-7 h-7 rounded-xl bg-white/30" />
          </div>
          <h1 className="text-2xl font-semibold">Welcome to Glassroom</h1>
          <p className="text-sm text-muted mt-1">Sign in to continue</p>
        </div>
        <form onSubmit={onSubmit} className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm text-muted">Email</label>
            <input type="email" name="email" required
                   className="glass w-full rounded-xl px-4 py-3 outline-none focus:ring-2 ring-white/20 bg-white/5"
                   placeholder="you@school.edu" />
          </div>
          <div className="space-y-2">
            <label className="text-sm text-muted">Password</label>
            <input type="password" name="password" required
                   className="glass w-full rounded-xl px-4 py-3 outline-none focus:ring-2 ring-white/20 bg-white/5"
                   placeholder="••••••••" />
          </div>
          {error && <div className="text-rose-300 text-xs">{error}</div>}
          <button type="submit"
                  className="w-full rounded-xl px-4 py-3 glass hover:scale-[1.01] active:scale-[0.99] transition font-medium">
            Sign in
          </button>
          <div className="text-center text-xs text-muted">
            No account? <Link className="underline" to="/signup">Create one</Link>
          </div>
        </form>
      </GlassCard>
    </div>
  )
}
