import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import GlassCard from '../components/GlassCard'
import { motion } from 'framer-motion'
import { 
  Globe, 
  User, 
  Moon, 
  Sun, 
  Bell, 
  Shield, 
  Palette, 
  LogOut, 
  ChevronRight,
  Eye,
  EyeOff,
  Download,
  Trash2
} from 'lucide-react'
import { useTheme } from '../context/ThemeContext'
import { useLanguage } from '../context/LanguageContext'

export default function Settings() {
  const navigate = useNavigate()
  const { isDark, toggleTheme } = useTheme()
  const { language, changeLanguage, t } = useLanguage()
  const [notifications, setNotifications] = useState(true)
  const [showPassword, setShowPassword] = useState(false)

  const handleLogout = () => {
    localStorage.removeItem('user')
    navigate('/signin')
  }

  const SettingItem = ({ icon: Icon, title, subtitle, action, onClick, danger = false }) => (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <GlassCard 
        className={`p-4 hover:bg-white/5 transition-colors cursor-pointer ${danger ? 'hover:bg-red-500/10' : ''}`}
        onClick={onClick}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className={`glass rounded-full p-2 flex-shrink-0 ${danger ? 'bg-red-500/20' : ''}`}>
              <Icon size={18} className={danger ? 'text-red-400' : ''} />
            </div>
            <div>
              <div className={`font-medium ${danger ? 'text-red-400' : ''}`}>{title}</div>
              <div className="text-sm text-muted">{subtitle}</div>
            </div>
          </div>
          {action && (
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted">{action}</span>
              <ChevronRight size={16} className="text-muted" />
            </div>
          )}
        </div>
      </GlassCard>
    </motion.div>
  )

  const ToggleItem = ({ icon: Icon, title, subtitle, value, onChange }) => (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <GlassCard className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="glass rounded-full p-2 flex-shrink-0">
              <Icon size={18} />
            </div>
            <div>
              <div className="font-medium">{title}</div>
              <div className="text-sm text-muted">{subtitle}</div>
            </div>
          </div>
          <button
            onClick={onChange}
            className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
              value ? 'bg-blue-500' : 'bg-gray-600'
            }`}
          >
            <span
              className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                value ? 'translate-x-6' : 'translate-x-1'
              }`}
            />
          </button>
        </div>
      </GlassCard>
    </motion.div>
  )

  return (
    <div className="space-y-6 content-scroll">
      <GlassCard className="flex items-center justify-between">
                          <div>
                    <div className="text-xl font-semibold">{t('settings')}</div>
                    <div className="text-muted text-sm">Manage your account preferences</div>
                  </div>
        <div className="text-xs glass rounded-full px-3 py-1">Account</div>
      </GlassCard>

      <div className="space-y-4">
        <div className="space-y-3">
          <h3 className="text-sm font-medium text-muted uppercase tracking-wider">Profile</h3>
          <SettingItem
            icon={User}
            title="Account Information"
            subtitle="Update your personal details"
            action="Edit"
            onClick={() => alert('Edit profile modal')}
          />
          <SettingItem
            icon={Eye}
            title="Change Password"
            subtitle="Update your password"
            action="Change"
            onClick={() => alert('Change password modal')}
          />
        </div>

        <div className="space-y-3">
          <h3 className="text-sm font-medium text-muted uppercase tracking-wider">Preferences</h3>
            <SettingItem
              icon={Globe}
              title="Language"
              subtitle={`Current: ${
                language === 'en' ? 'English' : 
                language === 'ru' ? 'Русский' : 
                language === 'de' ? 'Deutsch' : 
                'Français'
              }`}
              action={
                language === 'en' ? 'English' : 
                language === 'ru' ? 'Русский' : 
                language === 'de' ? 'Deutsch' : 
                'Français'
              }
              onClick={() => {
                const languages = ['en', 'ru', 'de', 'fr'];
                const currentIndex = languages.indexOf(language);
                const nextIndex = (currentIndex + 1) % languages.length;
                changeLanguage(languages[nextIndex]);
              }}
            />
          <SettingItem
            icon={isDark ? Moon : Sun}
            title="Theme"
            subtitle={`Current: ${isDark ? 'Dark' : 'Light'}`}
            action={isDark ? 'Dark' : 'Light'}
            onClick={toggleTheme}
          />
          <ToggleItem
            icon={Bell}
            title="Notifications"
            subtitle="Receive updates about assignments"
            value={notifications}
            onChange={() => setNotifications(!notifications)}
          />
        </div>

        <div className="space-y-3">
          <h3 className="text-sm font-medium text-muted uppercase tracking-wider">Privacy & Security</h3>
          <SettingItem
            icon={Shield}
            title="Privacy Settings"
            subtitle="Manage your privacy preferences"
            action="Configure"
            onClick={() => alert('Privacy settings modal')}
          />
          <SettingItem
            icon={Download}
            title="Export Data"
            subtitle="Download your course data"
            action="Export"
            onClick={() => alert('Export data modal')}
          />
        </div>

        <div className="space-y-3">
          <h3 className="text-sm font-medium text-muted uppercase tracking-wider">Account</h3>
          <SettingItem
            icon={Trash2}
            title="Delete Account"
            subtitle="Permanently delete your account"
            action="Delete"
            danger={true}
            onClick={() => {
              if (confirm('Are you sure you want to delete your account? This action cannot be undone.')) {
                alert('Account deletion initiated')
              }
            }}
          />
          <SettingItem
            icon={LogOut}
            title="Sign Out"
            subtitle="Sign out of your account"
            action="Sign Out"
            danger={true}
            onClick={handleLogout}
          />
        </div>
      </div>
    </div>
  )
}
