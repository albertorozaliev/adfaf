import { useState, useEffect } from 'react'

export const useAttachments = (assignmentId) => {
  const [attachments, setAttachments] = useState([])

  // Загружаем файлы из localStorage при инициализации
  useEffect(() => {
    const savedAttachments = localStorage.getItem(`attachments_${assignmentId}`)
    if (savedAttachments) {
      try {
        setAttachments(JSON.parse(savedAttachments))
      } catch (error) {
        console.error('Ошибка при загрузке прикрепленных файлов:', error)
      }
    }
  }, [assignmentId])

  // Сохраняем файлы в localStorage при изменении
  const updateAttachments = (newAttachments) => {
    setAttachments(newAttachments)
    localStorage.setItem(`attachments_${assignmentId}`, JSON.stringify(newAttachments))
  }

  // Добавляем новые файлы
  const addAttachments = (newAttachments) => {
    const formattedAttachments = []
    
    // Добавляем файлы
    newAttachments.files.forEach(file => {
      formattedAttachments.push({
        id: Date.now() + Math.random(),
        type: 'file',
        name: file.name,
        size: `${(file.size / 1024 / 1024).toFixed(2)} MB`,
        url: URL.createObjectURL(file)
      })
    })
    
    // Добавляем ссылки
    newAttachments.links.forEach(link => {
      if (link.trim()) {
        formattedAttachments.push({
          id: Date.now() + Math.random(),
          type: 'link',
          name: link,
          url: link
        })
      }
    })
    
    // Добавляем файлы из Google Drive
    newAttachments.driveFiles.forEach(file => {
      formattedAttachments.push({
        id: Date.now() + Math.random(),
        type: 'file',
        name: file.name,
        size: 'Google Drive',
        url: '#'
      })
    })
    
    const updatedAttachments = [...attachments, ...formattedAttachments]
    updateAttachments(updatedAttachments)
  }

  // Удаляем файл
  const removeAttachment = (attachmentId) => {
    const updatedAttachments = attachments.filter(att => att.id !== attachmentId)
    updateAttachments(updatedAttachments)
  }

  return {
    attachments,
    addAttachments,
    removeAttachment,
    updateAttachments
  }
}
