import { useState, useEffect } from 'react'

export const useGrades = (assignmentId) => {
  const [grade, setGrade] = useState(null)

  // Загружаем оценку из localStorage при инициализации
  useEffect(() => {
    const savedGrade = localStorage.getItem(`grade_${assignmentId}`)
    if (savedGrade) {
      try {
        setGrade(JSON.parse(savedGrade))
      } catch (error) {
        console.error('Ошибка при загрузке оценки:', error)
      }
    }
  }, [assignmentId])

  // Сохраняем оценку в localStorage
  const updateGrade = (newGrade) => {
    setGrade(newGrade)
    localStorage.setItem(`grade_${assignmentId}`, JSON.stringify(newGrade))
  }

  return {
    grade,
    updateGrade
  }
}
