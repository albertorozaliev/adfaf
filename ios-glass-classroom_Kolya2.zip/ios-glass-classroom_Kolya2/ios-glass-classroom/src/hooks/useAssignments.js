import { useState, useEffect } from 'react'

// Начальные данные о заданиях (соответствуют структуре из CourseDetail)
const initialAssignmentData = {
  1: {
    id: 1,
    title: 'Глава 5: Квадратные уравнения',
    description: `Выполните упражнения 1-20 из учебника. Покажите все решения и отправьте ваши ответы.

Требования к работе:
• Все решения должны быть подробно расписаны
• Используйте правильную математическую нотацию
• Проверьте все ответы
• Работа должна быть аккуратно оформлена

Дополнительные материалы:
• Учебник: "Алгебра II" - глава 5
• Видеоурок: "Решение квадратных уравнений"
• Практические примеры в приложении

Критерии оценки:
• Правильность решений (60%)
• Оформление работы (20%)
• Время выполнения (20%)`,
    dueDate: '2025-12-15',
    course: 'Алгебра II',
    teacher: 'Анна Петрова',
    progress: 25,
    completed: false,
    grade: null,
    maxGrade: 5,
    attachments: []
  },
  2: {
    id: 2,
    title: 'Подготовка к экзамену',
    description: `Повторите главы 1-4 и выполните практические задачи. Экзамен будет охватывать весь материал.`,
    dueDate: '2025-12-18',
    course: 'Алгебра II',
    teacher: 'Анна Петрова',
    progress: 100,
    completed: true,
    grade: 5,
    maxGrade: 5,
    attachments: []
  },
  3: {
    id: 3,
    title: 'Групповой проект: Применение в реальном мире',
    description: `Работайте с группой, чтобы найти реальные применения квадратных уравнений. Представьте ваши находки.`,
    dueDate: '2025-12-22',
    course: 'Алгебра II',
    teacher: 'Анна Петрова',
    progress: 60,
    completed: false,
    grade: null,
    maxGrade: 5,
    attachments: []
  },
  4: {
    id: 4,
    title: 'Эссе: Революции XVIII века',
    description: `Напишите сравнительный анализ Французской и Американской революций. Минимум 1500 слов.

Структура эссе:
1. Введение (200-300 слов)
2. Основная часть (1000-1200 слов)
   - Французская революция
   - Американская революция
   - Сравнительный анализ
3. Заключение (200-300 слов)

Требования:
• Используйте академический стиль
• Приводите конкретные примеры и даты
• Используйте не менее 5 источников
• Оформите список литературы

Источники для изучения:
• "Декларация независимости США"
• "Декларация прав человека и гражданина"
• Лекции по истории революций`,
    dueDate: '2025-12-16',
    course: 'Всемирная История',
    teacher: 'Дмитрий Соколов',
    progress: 40,
    completed: false,
    grade: 4,
    maxGrade: 5,
    attachments: []
  },
  5: {
    id: 5,
    title: 'Презентация: Империи XIX века',
    description: `Подготовьте презентацию о Британской империи и её влиянии на современный мир.`,
    dueDate: '2025-12-19',
    course: 'Всемирная История',
    teacher: 'Дмитрий Соколов',
    progress: 80,
    completed: false,
    grade: null,
    maxGrade: 5,
    attachments: []
  },
  6: {
    id: 6,
    title: 'Исследовательская работа: Холодная война',
    description: `Исследуйте ключевые события Холодной войны и их влияние на современную геополитику.`,
    dueDate: '2025-12-25',
    course: 'Всемирная История',
    teacher: 'Дмитрий Соколов',
    progress: 15,
    completed: false,
    grade: null,
    maxGrade: 5,
    attachments: []
  },
  7: {
    id: 7,
    title: 'Лабораторная работа: Механика',
    description: `Проведите эксперимент по изучению движения тел под действием силы тяжести.

Требования:
• Запишите все измерения
• Постройте графики
• Сделайте выводы
• Оформите отчет`,
    dueDate: '2025-12-14',
    course: 'Физика',
    teacher: 'Елена Иванова',
    progress: 100,
    completed: true,
    grade: 5,
    maxGrade: 5,
    attachments: []
  },
  8: {
    id: 8,
    title: 'Расчетная работа: Электричество',
    description: `Решите задачи по электрическим цепям и закону Ома. Покажите все вычисления.`,
    dueDate: '2025-12-17',
    course: 'Физика',
    teacher: 'Елена Иванова',
    progress: 70,
    completed: false,
    grade: null,
    maxGrade: 5,
    attachments: []
  },
  9: {
    id: 9,
    title: 'Проект: Создание простого двигателя',
    description: `Создайте модель простого электродвигателя и объясните принцип его работы.`,
    dueDate: '2025-12-23',
    course: 'Физика',
    teacher: 'Елена Иванова',
    progress: 30,
    completed: false,
    grade: null,
    maxGrade: 5,
    attachments: []
  }
}

export const useAssignments = () => {
  const [assignments, setAssignments] = useState(initialAssignmentData)

  // Загружаем задания из localStorage при инициализации
  useEffect(() => {
    const savedAssignments = localStorage.getItem('assignments')
    if (savedAssignments) {
      try {
        const parsed = JSON.parse(savedAssignments)
        setAssignments(parsed)
      } catch (error) {
        console.error('Ошибка при загрузке заданий:', error)
      }
    }
  }, [])

  // Сохраняем задания в localStorage при изменении
  const updateAssignments = (newAssignments) => {
    setAssignments(newAssignments)
    localStorage.setItem('assignments', JSON.stringify(newAssignments))
  }

  // Добавляем новое задание
  const addAssignment = (assignment) => {
    const newAssignments = {
      ...assignments,
      [assignment.id]: assignment
    }
    updateAssignments(newAssignments)
    return assignment
  }

  // Получаем задание по ID
  const getAssignment = (id) => {
    return assignments[id] || null
  }

  // Обновляем задание
  const updateAssignment = (id, updates) => {
    const newAssignments = {
      ...assignments,
      [id]: {
        ...assignments[id],
        ...updates
      }
    }
    updateAssignments(newAssignments)
  }

  // Удаляем задание
  const deleteAssignment = (id) => {
    const newAssignments = { ...assignments }
    delete newAssignments[id]
    updateAssignments(newAssignments)
  }

  return {
    assignments,
    addAssignment,
    getAssignment,
    updateAssignment,
    deleteAssignment
  }
}
