import React from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import { ThemeProvider } from './context/ThemeContext'
import { LanguageProvider } from './context/LanguageContext'
import SignIn from './pages/SignIn'
import SignUp from './pages/SignUp'
import Layout from './pages/Layout'
import Overview from './pages/Overview'
import MyCourses from './pages/MyCourses'
import Recent from './pages/Recent'
import Settings from './pages/Settings'
import CourseDetail from './pages/CourseDetail'
import AssignmentDetail from './pages/AssignmentDetail'
import Grades from './pages/Grades'
import MainWindow from './pages/MainWindow'

export default function App() {
  return (
    <ThemeProvider>
      <LanguageProvider>
        <Routes>
          <Route path="/" element={<Navigate to="/overview" />} />
          <Route path="/signin" element={<SignIn />} />
          <Route path="/signup" element={<SignUp />} />
          <Route element={<Layout />}>
            <Route path="/mainwindow" element={<MainWindow/>} />
            <Route path="/overview" element={<Overview />} />
            <Route path="/my-courses" element={<MyCourses />} />
            <Route path="/recent" element={<Recent />} />
            <Route path="/settings" element={<Settings />} />
            <Route path="/course/:id" element={<CourseDetail />} />
            <Route path="/course/:courseId/assignment/:assignmentId" element={<AssignmentDetail />} />
            <Route path="/course/:courseId/assignment/:assignmentId/grades" element={<Grades />} />
            <Route path="*" element={<Navigate to="/overview" />} />
          </Route>
        </Routes>
      </LanguageProvider>
    </ThemeProvider>
  )
}
