/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['SF Pro Display', 'ui-sans-serif', 'system-ui', 'Apple Color Emoji']
      },
      colors: {
        'ink': '#e5e7eb',
        'muted': '#9ca3af'
      },
      boxShadow: {
        'glass': '0 10px 30px rgba(0,0,0,.35), inset 0 0 0 1px rgba(255,255,255,.08)',
        'neon': '0 0 40px rgba(0,255,255,.25)'
      },
      backgroundImage: {
        'mesh': 'radial-gradient(1200px 600px at 10% -10%, rgba(0, 128, 255, 0.25), transparent 60%), radial-gradient(800px 400px at 90% 10%, rgba(255, 0, 200, 0.2), transparent 60%), radial-gradient(1000px 500px at 50% 120%, rgba(0, 255, 200, 0.22), transparent 60%)'
      },
      animation: {
        'float': 'float 12s ease-in-out infinite'
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-12px)' }
        }
      },
      backdropBlur: {
        xs: '2px'
      }
    },
  },
  plugins: [],
}
