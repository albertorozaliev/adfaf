# Glassroom (Google Classroom-style UI)

Dark, liquid-glass, iOS-inspired classroom clone built with Vite + React + Tailwind + Framer Motion.

## Quick start

```bash
npm i
npm run dev
```

Visit http://localhost:5173

## Notes

- Auth is localStorage-only for demo. Sign up first, then sign in.
- Replace `/src/lib/auth.js` with real API calls later.
- Design: dark, glassmorphism, smooth animations, heavy but optimised.
- Tech: React 18, React Router v6, Tailwind 3, Framer Motion, Vite.
