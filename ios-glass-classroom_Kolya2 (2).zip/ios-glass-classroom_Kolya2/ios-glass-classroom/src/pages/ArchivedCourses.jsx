import React from 'react';
import { useCourses } from '../hooks/useCourses';
import CourseCard from '../components/CourseCard';

const ArchivedCourses = () => {
  const { getArchivedCourses, restoreCourse } = useCourses();
  const archivedCourses = getArchivedCourses();

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Архивированные курсы</h1>

      {archivedCourses.length === 0 ? (
        <p className="text-muted">Архив пуст.</p>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {archivedCourses.map(course => (
            <div key={course.id} className="relative">
              <CourseCard course={course} />
              <button
                onClick={() => restoreCourse(course.id)}
                className="absolute top-2 right-2 bg-green-500/20 text-green-600 px-3 py-1 rounded-lg text-sm hover:bg-green-500/30 transition-colors"
              >
                Восстановить
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default ArchivedCourses;
