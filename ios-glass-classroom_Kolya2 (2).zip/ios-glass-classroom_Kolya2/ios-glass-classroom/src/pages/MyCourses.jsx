import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import CourseCard from '../components/CourseCard'
import GlassCard from '../components/GlassCard'
import CreateCourseModal from '../components/CreateCourseModal'
import { motion } from 'framer-motion'
import { Plus } from 'lucide-react'
import { useCourses } from '../hooks/useCourses'
import { useHistory } from '../hooks/useHistory'

export default function MyCourses() {
  const navigate = useNavigate()
  const { courses, addCourse, getColorClass } = useCourses()
  const { addCourseCreated } = useHistory()
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false)

  const handleCourseClick = (courseId) => {
    navigate(`/course/${courseId}`)
  }

  const handleCreateCourse = (courseData) => {
    const newCourse = addCourse(courseData)
    addCourseCreated(newCourse)
  }

  return (
    <div className="space-y-6 content-scroll">
      <GlassCard className="flex items-center justify-between">
        <div>
          <div className="text-xl font-semibold">Мои Курсы</div>
          <div className="text-muted text-sm">Все ваши записанные классы</div>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-xs glass rounded-full px-3 py-1">{courses.length} Курсов</div>
                                <button
                        onClick={() => setIsCreateModalOpen(true)}
                        className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl text-white text-sm font-medium hover:from-blue-600 hover:to-purple-700 transition-all shadow-lg hover:shadow-xl"
                      >
                        <Plus className="w-4 h-4 text-white" />
                        <span className="text-white">Создать курс</span>
                      </button>
        </div>
      </GlassCard>

      <motion.div
        className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4 lg:gap-6"
        initial="hidden"
        animate="show"
        variants={{ hidden: {}, show: { transition: { staggerChildren: 0.06 } } }}
      >
        {courses.map((course, i) => (
          <motion.div 
            key={course.id} 
            variants={{ hidden: { opacity: 0, y: 12 }, show: { opacity: 1, y: 0 } }}
            className="h-48 flex w-full"
          >
                                    <CourseCard
                          id={course.id}
                          title={course.title}
                          teacher={course.teacher}
                          color={`linear-gradient(135deg, var(--tw-gradient-from), var(--tw-gradient-to))`}
                          colorClass={getColorClass(course.color)}
                          onClick={() => handleCourseClick(course.id)}
                        />
          </motion.div>
        ))}
      </motion.div>

      <CreateCourseModal 
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        onCreateCourse={handleCreateCourse}
      />
    </div>
  )
}
