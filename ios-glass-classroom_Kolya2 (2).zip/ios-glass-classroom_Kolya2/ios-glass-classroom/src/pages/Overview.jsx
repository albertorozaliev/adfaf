import React, { useEffect, useState } from 'react'
import GlassCard from '../components/GlassCard'
import { motion } from 'framer-motion'

const days = ['Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота']

const scheduleByDay = {
  Понедельник: [
    { subject: 'Математика', teacher: 'Иванов И.И.', room: '101' },
    { subject: 'Физика', teacher: 'Петров П.П.', room: '202' },
    { subject: 'Информатика', teacher: 'Смирнова А.А.', room: '303' },
    { subject: 'Литература', teacher: 'Кузнецова Н.Н.', room: '110' },
    { subject: 'Английский язык', teacher: 'Белова О.О.', room: '204' },
  ],
  Вторник: [
    { subject: 'Биология', teacher: 'Сидоров С.С.', room: '305' },
    { subject: 'География', teacher: 'Михайлова Л.Л.', room: '120' },
    { subject: 'Алгебра', teacher: 'Новиков В.В.', room: '101' },
    { subject: 'Физкультура', teacher: 'Орлов Д.Д.', room: 'спортзал' },
    { subject: 'ИЗО', teacher: 'Климова Е.Е.', room: '207' },
  ],
  Среда: [
    { subject: 'Химия', teacher: 'Козлова Т.Т.', room: '110' },
    { subject: 'История', teacher: 'Романов А.А.', room: '115' },
    { subject: 'Геометрия', teacher: 'Лебедев М.М.', room: '101' },
    { subject: 'Музыка', teacher: 'Горбунова И.И.', room: '308' },
    { subject: 'ОБЖ', teacher: 'Филатов П.П.', room: '212' },
  ],
  Четверг: [
    { subject: 'Русский язык', teacher: 'Васильева Н.Н.', room: '102' },
    { subject: 'Физика (лаборатория)', teacher: 'Петров П.П.', room: 'лаборатория 2' },
    { subject: 'Обществознание', teacher: 'Морозова Е.Е.', room: '118' },
    { subject: 'Технология', teacher: 'Соловьёв К.К.', room: '202' },
    { subject: 'Литература', teacher: 'Кузнецова Н.Н.', room: '110' },
  ],
  Пятница: [
    { subject: 'Английский язык', teacher: 'Белова О.О.', room: '204' },
    { subject: 'Математика', teacher: 'Иванов И.И.', room: '101' },
    { subject: 'Информатика', teacher: 'Смирнова А.А.', room: '303' },
    { subject: 'Химия (лаборатория)', teacher: 'Козлова Т.Т.', room: 'лаборатория 1' },
    { subject: 'Физкультура', teacher: 'Орлов Д.Д.', room: 'спортзал' },
  ],
  Суббота: [
    { subject: 'Повторение', teacher: 'Иванов И.И.', room: '101' },
    { subject: 'Проекты', teacher: 'Смирнова А.А.', room: '303' },
    { subject: 'Кружок программирования', teacher: 'Лебедев М.М.', room: '404' },
    { subject: 'Английский', teacher: 'Белова О.О.', room: '204' },
    { subject: 'ИЗО', teacher: 'Климова Е.Е.', room: '207' },
  ],
}


const FIRST_LESSON_START = { hours: 8, minutes: 30 } 
const LESSON_DURATION_MIN = 90 
const BREAK_DURATION_MIN = 15

function minutesToHHMM(totalMinutes) {
  const h = Math.floor(totalMinutes / 60)
  const m = totalMinutes % 60
  const hh = String(h).padStart(2, '0')
  const mm = String(m).padStart(2, '0')
  return `${hh}:${mm}`
}

function buildTimesForCount(count) {
  const startOfDayMinutes = FIRST_LESSON_START.hours * 60 + FIRST_LESSON_START.minutes
  const times = []
  for (let i = 0; i < count; i++) {
    const lessonStart = startOfDayMinutes + i * (LESSON_DURATION_MIN + BREAK_DURATION_MIN)
    const lessonEnd = lessonStart + LESSON_DURATION_MIN
    times.push(`${minutesToHHMM(lessonStart)} — ${minutesToHHMM(lessonEnd)}`)
  }
  return times
}

export default function Schedule() {
  const [openDay, setOpenDay] = useState(null) 
  const [times, setTimes] = useState([])

  useEffect(() => {
    if (openDay) {

      setTimes(buildTimesForCount(5))
    }
  }, [openDay])

  useEffect(() => {
    function onKey(e) {
      if (e.key === 'Escape') setOpenDay(null)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [])

  return (
    <div className="space-y-6">
      <GlassCard className="flex items-center justify-between">
        <div>
          <div className="text-xl font-semibold">Расписание</div>
          <div className="text-muted text-sm">Нажмите на день, чтобы посмотреть расписание</div>
        </div>
      </GlassCard>

      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <GlassCard className="p-6">
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
            {days.map(day => (
              <button
                key={day}
                onClick={() => setOpenDay(day)}
                className="glass rounded-xl px-4 py-3 text-sm font-medium hover:scale-[1.02] transition-shadow shadow-sm"
              >
                {day}
              </button>
            ))}
          </div>
        </GlassCard>
      </motion.div>

      {/* Модальное окно с расписанием для выбранного дня */}
      {openDay && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center"
          onClick={() => setOpenDay(null)}
        >
          <div className="absolute inset-0 bg-black/40" />

          <motion.div
            initial={{ scale: 0.95, opacity: 0, y: 10 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.95, opacity: 0 }}
            transition={{ duration: 0.18 }}
            className="relative z-10 w-full max-w-3xl px-4"
            onClick={e => e.stopPropagation()}
          >
            <GlassCard className="p-6">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <div className="text-lg font-semibold">{openDay} — Расписание</div>
                  <div className="text-muted text-sm">Каждое занятие — 1.5 часа, перемена 15 минут</div>
                </div>
                <div>
                  <button
                    onClick={() => setOpenDay(null)}
                    className="glass rounded-full px-3 py-1 text-sm"
                    aria-label="Закрыть"
                  >
                    Закрыть
                  </button>
                </div>
              </div>

              <div className="mt-4 overflow-x-auto">
                <table className="w-full text-sm border-collapse">
                  <thead>
                    <tr className="text-left border-b border-muted">
                      <th className="p-2">Время</th>
                      <th className="p-2">Предмет</th>
                      <th className="p-2">Кабинет</th>
                      <th className="p-2">Преподаватель</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(scheduleByDay[openDay] || []).map((lesson, idx) => (
                      <tr key={idx} className="border-b border-muted/50 hover:bg-muted/10 transition">
                        <td className="p-2 font-medium">{times[idx] || '-'}</td>
                        <td className="p-2">{lesson.subject}</td>
                        <td className="p-2">{lesson.room}</td>
                        <td className="p-2">{lesson.teacher}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </GlassCard>
          </motion.div>
        </div>
      )}
    </div>
  )
}
