import React, { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { 
  ArrowLeft, 
  User, 
  FileText, 
  Link, 
  CheckCircle, 
  XCircle, 
  Star,
  Download,
  Eye
} from 'lucide-react'
import GlassCard from '../components/GlassCard'
import { useLanguage } from '../context/LanguageContext'
import { useCourses } from '../hooks/useCourses'
import { useAssignments } from '../hooks/useAssignments'
import { useAttachments } from '../hooks/useAttachments'
import { useGrades } from '../hooks/useGrades'

export default function Grades() {
  const { courseId, assignmentId } = useParams()
  const navigate = useNavigate()
  const { t } = useLanguage()
  const { getCourse } = useCourses()
  const { getAssignment } = useAssignments()
  const { getGrades, updateGrade } = useGrades()
  
  const [selectedStudent, setSelectedStudent] = useState(null)
  const [showAttachments, setShowAttachments] = useState(false)
  
  const course = getCourse(courseId)
  const assignment = getAssignment(parseInt(assignmentId))
  
  if (!course || !assignment) {
    return <div>Курс или задание не найдено</div>
  }

  const students = [
    { id: 1, name: 'Алексей Смирнов', submitted: true, submittedLate: false, grade: 4 },
    { id: 2, name: 'Софья Козлова', submitted: true, submittedLate: false, grade: 5 },
    { id: 3, name: 'Михаил Волков', submitted: false, submittedLate: false, grade: null },
    { id: 4, name: 'Елена Соколова', submitted: true, submittedLate: true, grade: 3 },
    { id: 5, name: 'Дмитрий Новиков', submitted: false, submittedLate: false, grade: null },
    { id: 6, name: 'Анна Кузнецова', submitted: true, submittedLate: false, grade: 5 }
  ]

  const handleGradeChange = (studentId, newGrade) => {
    updateGrade(assignmentId, newGrade)
    const updatedStudents = students.map(student => 
      student.id === studentId ? { ...student, grade: newGrade } : student
    )
  }

  const handleStudentClick = (student) => {
    setSelectedStudent(student)
    setShowAttachments(true)
  }

  const StudentRow = ({ student }) => (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass rounded-2xl p-4 hover:bg-white/5 transition-colors cursor-pointer"
      onClick={() => handleStudentClick(student)}
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="text-2xl">👨‍🎓</div>
          <div>
            <div className="font-medium">{student.name}</div>
                         <div className="text-sm text-muted flex items-center gap-2">
               {student.submittedLate ? (
                 <span className="text-orange-400 flex items-center gap-1">
                   <CheckCircle size={14} />
                   Сдано с опозданием
                 </span>
               ) : student.submitted ? (
                 <span className="text-green-400 flex items-center gap-1">
                   <CheckCircle size={14} />
                   Работа сдана
                 </span>
               ) : (
                 <span className="text-red-400 flex items-center gap-1">
                   <XCircle size={14} />
                   Не сдано
                 </span>
               )}
             </div>
          </div>
        </div>
        
        <div className="flex items-center gap-3">
               {/* удаление максимума */}
          <div className="flex items-center gap-2">
            <input
              type="number"
              min="0"
              max={assignment.maxGrade || 5}
              value={student.grade || ''}
              onChange={(e) => {
                e.stopPropagation()
                const value = e.target.value === '' ? null : parseInt(e.target.value)
                handleGradeChange(student.id, value)
              }}
              onClick={(e) => e.stopPropagation()}
              className="w-16 px-2 py-1 glass rounded-lg text-center text-sm focus:outline-none focus:ring-2 focus:ring-blue-400"
              placeholder="0"
            />
            <span className="text-sm text-muted">/ {assignment.maxGrade || 5}</span>
          </div>
        </div>
      </div>
    </motion.div>
  )

  const AttachmentsModal = ({ student, isOpen, onClose }) => {
    const { attachments } = useAttachments(assignmentId)
    
    if (!isOpen) return null

    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="w-full max-w-2xl"
          onClick={(e) => e.stopPropagation()}
        >
          <GlassCard className="p-6 space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-semibold">Работа студента</h2>
                <p className="text-sm text-muted">{student.name}</p>
              </div>
              <button
                onClick={onClose}
                className="glass rounded-full p-2 hover:bg-white/10 transition-colors"
              >
                <XCircle size={18} />
              </button>
            </div>

            <div className="space-y-4">
              {attachments.length > 0 ? (
                attachments.map((attachment, index) => (
                  <div key={index} className="glass rounded-xl p-4 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      {attachment.type === 'link' ? (
                        <Link size={16} className="text-blue-400" />
                      ) : (
                        <FileText size={16} className="text-green-400" />
                      )}
                      <div>
                        <div className="font-medium">{attachment.name}</div>
                        <div className="text-xs text-muted">
                          {attachment.type === 'link' ? 'Ссылка' : attachment.size}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <a
                        href={attachment.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="glass rounded-lg px-3 py-2 text-sm hover:bg-white/10 transition-colors flex items-center gap-2"
                      >
                        <Eye size={14} />
                        Просмотреть
                      </a>
                      {attachment.type !== 'link' && (
                        <button className="glass rounded-lg px-3 py-2 text-sm hover:bg-white/10 transition-colors flex items-center gap-2">
                          <Download size={14} />
                          Скачать
                        </button>
                      )}
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8 text-muted">
                  <FileText size={48} className="mx-auto mb-4 opacity-50" />
                  <p>Нет прикрепленных файлов</p>
                </div>
              )}
            </div>
          </GlassCard>
        </motion.div>
      </motion.div>
    )
  }

  return (
    <div className="space-y-6 content-scroll">
      <GlassCard className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate(`/course/${courseId}`)}
            className="glass rounded-full p-2 hover:bg-white/10 transition-colors"
          >
            <ArrowLeft size={18} />
          </button>
          <div>
            <div className="text-xl font-semibold">Оценки</div>
            <div className="text-muted text-sm">
              {course.title} • {assignment.title}
            </div>
          </div>
        </div>
        <div className="text-xs glass rounded-full px-3 py-1">
          {students.filter(s => s.submitted).length} из {students.length} сдали
        </div>
      </GlassCard>

      <div className="space-y-4">
        <div className="flex items-center gap-2 mb-4">
          <Star size={20} className="text-yellow-400" />
          <h3 className="text-lg font-semibold">Список студентов</h3>
        </div>
        
        {students.map((student) => (
          <StudentRow key={student.id} student={student} />
        ))}
      </div>

      <AttachmentsModal
        student={selectedStudent}
        isOpen={showAttachments}
        onClose={() => {
          setShowAttachments(false)
          setSelectedStudent(null)
        }}
      />
    </div>
  )
}
