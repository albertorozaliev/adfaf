import React from 'react'
import { Outlet, useNavigate } from 'react-router-dom'
import { getUser } from '../lib/auth'
import NavBar from '../components/NavBar'
import Sidebar from '../components/Sidebar'
import { motion } from 'framer-motion'

export default function Layout() {
  const nav = useNavigate()
  const user = getUser()
  React.useEffect(() => {
    if (!user?.authed) nav('/signin')
  }, [])

  return (
    <div className="relative min-h-screen text-ink font-sans ios-scroll">
      <motion.div
        className="fixed inset-0 -z-10 bg-mesh"
        initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1.2 }}
      />
      <div className="fixed -z-10 w-[90vmin] h-[90vmin] rounded-full blur-3xl opacity-20 left-1/2 -translate-x-1/2 -top-32"
           style={{ background: 'var(--gradient-1)' }} />
      <NavBar onNewCourse={() => alert('New course modal placeholder')} />
      <main className="pt-24 w-full max-w-6xl mx-auto flex gap-4 px-2">
        <Sidebar />
        <div className="flex-1 content-scroll">
          <Outlet />
        </div>
      </main>
    </div>
  )
}
