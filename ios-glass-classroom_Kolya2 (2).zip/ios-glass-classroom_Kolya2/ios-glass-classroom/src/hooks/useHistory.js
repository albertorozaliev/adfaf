import { useState, useEffect } from 'react';

// Начальная история
const initialHistory = [
  {
    id: 'history-1',
    type: 'assignment_created',
    title: 'Новое задание: Квадратные уравнения',
    description: 'Преподаватель Петров А.И. создал новое задание по математике',
    course: 'Математика',
    courseId: 'math-course',
    teacher: 'Петров А.И.',
    dueDate: '2025-01-25',
    createdAt: '2025-01-15T10:30:00Z'
  },
  {
    id: 'history-2',
    type: 'assignment_created',
    title: 'Новое задание: Законы Ньютона',
    description: 'Преподаватель Сидорова М.В. создал новое задание по физике',
    course: 'Физика',
    courseId: 'physics-course',
    teacher: 'Сидорова М.В.',
    dueDate: '2025-01-28',
    createdAt: '2025-01-14T14:15:00Z'
  },
  {
    id: 'history-3',
    type: 'assignment_created',
    title: 'Новое задание: Органические соединения',
    description: 'Преподаватель Иванов С.П. создал новое задание по химии',
    course: 'Химия',
    courseId: 'chemistry-course',
    teacher: 'Иванов С.П.',
    dueDate: '2025-01-30',
    createdAt: '2025-01-13T09:45:00Z'
  },
  {
    id: 'history-4',
    type: 'course_created',
    title: 'Создан новый курс: Биология',
    description: 'Добавлен новый курс по биологии',
    course: 'Биология',
    courseId: 'biology-course',
    teacher: 'Николаева Е.А.',
    createdAt: '2025-01-12T16:20:00Z'
  },
  {
    id: 'history-5',
    type: 'assignment_created',
    title: 'Новое задание: Великая Отечественная война',
    description: 'Преподаватель Волков Д.Н. создал новое задание по истории',
    course: 'История',
    courseId: 'history-course',
    teacher: 'Волков Д.Н.',
    dueDate: '2025-02-05',
    createdAt: '2025-01-11T11:00:00Z'
  }
];

export const useHistory = () => {
  const [history, setHistory] = useState(() => {
    const saved = localStorage.getItem('classroom-history');
    return saved ? JSON.parse(saved) : initialHistory;
  });

  useEffect(() => {
    localStorage.setItem('classroom-history', JSON.stringify(history));
  }, [history]);

  const addHistoryEvent = (eventData) => {
    const newEvent = {
      id: `history-${Date.now()}`,
      createdAt: new Date().toISOString(),
      ...eventData
    };
    
    setHistory(prev => [newEvent, ...prev]);
    return newEvent;
  };

  const addAssignmentCreated = (assignmentData, courseData) => {
    return addHistoryEvent({
      type: 'assignment_created',
      title: `Новое задание: ${assignmentData.title}`,
      description: `Преподаватель ${courseData.teacher} создал новое задание по курсу ${courseData.title}`,
      course: courseData.title,
      courseId: courseData.id,
      teacher: courseData.teacher,
      dueDate: assignmentData.dueDate,
      assignmentId: assignmentData.id
    });
  };

  const addCourseCreated = (courseData) => {
    return addHistoryEvent({
      type: 'course_created',
      title: `Создан новый курс: ${courseData.title}`,
      description: `Добавлен новый курс "${courseData.title}"`,
      course: courseData.title,
      courseId: courseData.id,
      teacher: courseData.teacher
    });
  };

  const addAssignmentSubmitted = (assignmentData, courseData, studentName) => {
    return addHistoryEvent({
      type: 'assignment_submitted',
      title: `Работа сдана: ${assignmentData.title}`,
      description: `${studentName} сдал работу по заданию "${assignmentData.title}"`,
      course: courseData.title,
      courseId: courseData.id,
      teacher: courseData.teacher,
      assignmentId: assignmentData.id,
      student: studentName
    });
  };

  const addGradeAssigned = (assignmentData, courseData, grade, studentName) => {
    return addHistoryEvent({
      type: 'grade_assigned',
      title: `Оценка выставлена: ${assignmentData.title}`,
      description: `Преподаватель ${courseData.teacher} выставил оценку ${grade} за задание "${assignmentData.title}"`,
      course: courseData.title,
      courseId: courseData.id,
      teacher: courseData.teacher,
      assignmentId: assignmentData.id,
      grade: grade,
      student: studentName
    });
  };

  const getHistoryByType = (type) => {
    return history.filter(event => event.type === type);
  };

  const getHistoryByCourse = (courseId) => {
    return history.filter(event => event.courseId === courseId);
  };

  const getRecentHistory = (limit = 10) => {
    return history
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
      .slice(0, limit);
  };

  const clearHistory = () => {
    setHistory([]);
  };

  const removeHistoryEvent = (eventId) => {
    setHistory(prev => prev.filter(event => event.id !== eventId));
  };

  const formatEventTime = (createdAt) => {
    const date = new Date(createdAt);
    const now = new Date();
    const diffMs = now - date;
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffMinutes = Math.floor(diffMs / (1000 * 60));

    if (diffMinutes < 1) return 'только что';
    if (diffMinutes < 60) return `${diffMinutes} мин назад`;
    if (diffHours < 24) return `${diffHours} ч назад`;
    if (diffDays < 7) return `${diffDays} д назад`;
    
    return date.toLocaleDateString('ru-RU', {
      day: 'numeric',
      month: 'short',
      year: date.getFullYear() !== now.getFullYear() ? 'numeric' : undefined
    });
  };

  return {
    history,
    addHistoryEvent,
    addAssignmentCreated,
    addCourseCreated,
    addAssignmentSubmitted,
    addGradeAssigned,
    getHistoryByType,
    getHistoryByCourse,
    getRecentHistory,
    clearHistory,
    removeHistoryEvent,
    formatEventTime
  };
};
