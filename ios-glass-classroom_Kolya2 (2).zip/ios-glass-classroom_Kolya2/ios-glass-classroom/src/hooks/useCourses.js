import { useState, useEffect } from 'react';

const initialCourses = [
  {
    id: '1', 
    title: 'Математика',
    teacher: 'Петров А.И.',
    color: 'blue',
    image: '/api/placeholder/300/200',
    archived: false
  },
  {
    id: '2', 
    title: 'История',
    teacher: 'Волков Д.Н.',
    color: 'orange',
    image: '/api/placeholder/300/200',
    archived: false
  },
  {
    id: '3', 
    title: 'Физика',
    teacher: 'Сидорова М.В.',
    color: 'green',
    image: '/api/placeholder/300/200',
    archived: false
  },
  {
    id: '4', 
    title: 'Литература',
    teacher: 'Морозова О.С.',
    color: 'pink',
    image: '/api/placeholder/300/200',
    archived: false
  },
  {
    id: '5', 
    title: 'Биология',
    teacher: 'Николаева Е.А.',
    color: 'red',
    image: '/api/placeholder/300/200',
    archived: false
  },
  {
    id: '6', 
    title: 'Химия',
    teacher: 'Иванов С.П.',
    color: 'purple',
    image: '/api/placeholder/300/200',
    archived: false
  }
];

export const courseColors = [
  { id: 'blue', name: 'Синий', class: 'from-blue-500 to-blue-700' },
  { id: 'green', name: 'Зеленый', class: 'from-green-500 to-green-700' },
  { id: 'purple', name: 'Фиолетовый', class: 'from-purple-500 to-purple-700' },
  { id: 'red', name: 'Красный', class: 'from-red-500 to-red-700' },
  { id: 'orange', name: 'Оранжевый', class: 'from-orange-500 to-orange-700' },
  { id: 'pink', name: 'Розовый', class: 'from-pink-500 to-pink-700' },
  { id: 'indigo', name: 'Индиго', class: 'from-indigo-500 to-indigo-700' },
  { id: 'teal', name: 'Бирюзовый', class: 'from-teal-500 to-teal-700' },
  { id: 'cyan', name: 'Голубой', class: 'from-cyan-500 to-cyan-700' },
  { id: 'yellow', name: 'Жёлтый', class: 'from-yellow-500 to-yellow-700'},
];

export const customColor = [
  {id: 'custom', name: 'custom', class: 'from-[#FF6B6B] to-[#4ECDC4]'}
];

export const useCourses = () => {
  const [courses, setCourses] = useState(() => {
    const saved = localStorage.getItem('classroom-courses');
    return saved ? JSON.parse(saved) : initialCourses;
  });

  const [customColors, setCustomColors] = useState(() => {
    const saved = localStorage.getItem('classroom-custom-colors');
    return saved ? JSON.parse(saved) : {};
  });

  useEffect(() => {
    localStorage.setItem('classroom-courses', JSON.stringify(courses));
  }, [courses]);

  useEffect(() => {
    localStorage.setItem('classroom-custom-colors', JSON.stringify(customColors));
  }, [customColors]);

  const addCourse = (courseData) => {
    const newCourse = {
      id: `course-${Date.now()}`,
      title: courseData.title,
      teacher: courseData.teacher,
      color: courseData.color,
      customColor: courseData.color === 'custom' ? courseData.customColor : undefined,
      image: '/api/placeholder/300/200',
      createdAt: new Date().toISOString(),
      archived: false
    };
    
    setCourses(prev => [...prev, newCourse]);

    if (courseData.color === 'custom' && courseData.customColor) {
      setCustomColors(prev => ({
        ...prev,
        [newCourse.id]: courseData.customColor
      }));
    }
    
    return newCourse;
  };

  const getCourse = (courseId) => {
    return courses.find(course => course.id === courseId);
  };

  const updateCourse = (courseId, updates) => {
    setCourses(prev => prev.map(course => {
      if (course.id === courseId) {
        const updatedCourse = { 
          ...course, 
          ...updates, 
          updatedAt: new Date().toISOString() 
        };

        if (updates.color === 'custom' && updates.customColor) {
          setCustomColors(prev => ({
            ...prev,
            [courseId]: updates.customColor
          }));
        } else if (updates.color && updates.color !== 'custom') {
          setCustomColors(prev => {
            const newColors = { ...prev };
            delete newColors[courseId];
            return newColors;
          });
        }
        
        return updatedCourse;
      }
      return course;
    }));
  };

  const deleteCourse = (courseId) => {
    setCourses(prev => prev.filter(course => course.id !== courseId));

    setCustomColors(prev => {
      const newColors = { ...prev };
      delete newColors[courseId];
      return newColors;
    });
  };

  // === Новое для архива ===
  const archiveCourse = (courseId) => {
    updateCourse(courseId, { archived: true });
  };

  const restoreCourse = (courseId) => {
    updateCourse(courseId, { archived: false });
  };

  const getActiveCourses = () => courses.filter(c => !c.archived);
  const getArchivedCourses = () => courses.filter(c => c.archived);

  // ========================

  const getColorClass = (colorId, courseId = null) => {
    if (colorId === 'custom' && courseId && customColors[courseId]) {
      return `from-[${customColors[courseId]}] to-[${customColors[courseId]}]90`;
    }
    
    const color = courseColors.find(c => c.id === colorId);
    return color ? color.class : 'from-blue-500 to-blue-700';
  };

  const getColorValue = (colorId, courseId = null) => {
    if (colorId === 'custom' && courseId && customColors[courseId]) {
      return customColors[courseId];
    }
    return null;
  };

  return {
    courses,
    customColors,
    addCourse,
    getCourse,
    updateCourse,
    deleteCourse,
    archiveCourse,
    restoreCourse,
    getActiveCourses,
    getArchivedCourses,
    getColorClass,
    getColorValue
  };
};
