import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Plus, Palette } from 'lucide-react';
import { courseColors } from '../hooks/useCourses';

const CreateCourseModal = ({ isOpen, onClose, onCreateCourse }) => {
  const [formData, setFormData] = useState({
    title: '',
    teacher: '',
    color: 'blue',
    customColor: '#FF6B6B'
  });

  const [errors, setErrors] = useState({});
  const [showCustomColorPicker, setShowCustomColorPicker] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    
    const newErrors = {};
    if (!formData.title.trim()) {
      newErrors.title = 'Название курса обязательно';
    }
    if (!formData.teacher.trim()) {
      newErrors.teacher = 'Имя преподавателя обязательно';
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }


    const courseData = {
      title: formData.title,
      teacher: formData.teacher,
      color: formData.color,
      customColor: formData.color === 'custom' ? formData.customColor : undefined
    };

    onCreateCourse(courseData);
    

    setFormData({
      title: '',
      teacher: '',
      color: 'blue',
      customColor: '#FF6B6B'
    });
    setErrors({});
    setShowCustomColorPicker(false);
    onClose();
  };

  const handleClose = () => {
    setFormData({
      title: '',
      teacher: '',
      color: 'blue',
      customColor: '#FF6B6B'
    });
    setErrors({});
    setShowCustomColorPicker(false);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
          onClick={(e) => e.target === e.currentTarget && handleClose()}
        >
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-6 w-full max-w-md relative shadow-2xl"
          >
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-white flex items-center gap-2">
                <Plus className="w-5 h-5" />
                Создать новый курс
              </h2>
              <button
                onClick={handleClose}
                className="p-2 rounded-full hover:bg-white/10 transition-colors"
              >
                <X className="w-5 h-5 text-white" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-white/80 mb-2">
                  Название курса
                </label>
                <input
                  type="text"
                  value={formData.title}
                  onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                  placeholder="Например: Математика"
                  className="w-full px-4 py-3 bg-white/10 backdrop-blur-md border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent transition-all"
                />
                {errors.title && (
                  <p className="text-red-400 text-sm mt-1">{errors.title}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-white/80 mb-2">
                  Преподаватель
                </label>
                <input
                  type="text"
                  value={formData.teacher}
                  onChange={(e) => setFormData(prev => ({ ...prev, teacher: e.target.value }))}
                  placeholder="Например: Иванов И.И."
                  className="w-full px-4 py-3 bg-white/10 backdrop-blur-md border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent transition-all"
                />
                {errors.teacher && (
                  <p className="text-red-400 text-sm mt-1">{errors.teacher}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-white/80 mb-3 flex items-center gap-2">
                  <Palette className="w-4 h-4" />
                  Цвет карточки
                </label>
                <div className="grid grid-cols-6 gap-2 mb-3">
                  {courseColors.map((color) => (
                    <button
                      key={color.id}
                      type="button"
                      onClick={() => {
                        setFormData(prev => ({ ...prev, color: color.id }));
                        setShowCustomColorPicker(false);
                      }}
                      className={`
                        w-10 h-10 rounded-xl bg-gradient-to-r ${color.class} 
                        transition-all duration-200 relative
                        ${formData.color === color.id 
                          ? 'ring-2 ring-white ring-offset-2 ring-offset-transparent scale-110' 
                          : 'hover:scale-105'
                        }
                      `}
                      title={color.name}
                    >
                      {formData.color === color.id && (
                        <motion.div
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          className="absolute inset-0 flex items-center justify-center"
                        >
                          <div className="w-3 h-3 bg-white rounded-full shadow-lg" />
                        </motion.div>
                      )}
                    </button>
                  ))}
                  <button
                    type="button"
                    onClick={() => {
                      setFormData(prev => ({ ...prev, color: 'custom' }));
                      setShowCustomColorPicker(true);
                    }}
                    className={`
                      w-10 h-10 rounded-xl border-2 transition-all duration-200 relative
                      ${formData.color === 'custom' 
                        ? 'ring-2 ring-white ring-offset-2 ring-offset-transparent scale-110 border-white' 
                        : 'hover:scale-105 border-white/20'
                      }
                    `}
                    style={{ 
                      background: `linear-gradient(to right, ${formData.customColor}, ${formData.customColor}90)`
                    }}
                    title="Выбрать свой цвет"
                  >
                    {formData.color === 'custom' && (
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="absolute inset-0 flex items-center justify-center"
                      >
                        <div className="w-3 h-3 bg-white rounded-full shadow-lg" />
                      </motion.div>
                    )}
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Palette className="w-4 h-4 text-white" />
                    </div>
                  </button>
                </div>

                {showCustomColorPicker && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    className="mt-3 p-3 bg-white/5 rounded-xl"
                  >
                    <label className="block text-sm font-medium text-white/80 mb-2">
                      Выберите свой цвет
                    </label>
                    <div className="flex items-center gap-3">
                      <div 
                        className="w-10 h-10 rounded-xl border border-white/20"
                        style={{ backgroundColor: formData.customColor }}
                      />
                      <div className="flex-1">
                        <input
                          type="color"
                          value={formData.customColor}
                          onChange={(e) => setFormData(prev => ({ 
                            ...prev, 
                            customColor: e.target.value,
                            color: 'custom'
                          }))}
                          className="w-full h-10 bg-white/5 border border-white/10 rounded-xl cursor-pointer"
                        />
                      </div>
                    </div>
                    <div className="text-sm text-white/60 mt-2">
                      Выбранный цвет: {formData.customColor}
                    </div>
                  </motion.div>
                )}
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={handleClose}
                  className="flex-1 px-4 py-3 bg-white/10 backdrop-blur-md border border-white/20 rounded-xl text-white font-medium hover:bg-white/20 transition-all"
                >
                  Отмена
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-3 bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl text-white font-medium hover:from-blue-600 hover:to-purple-700 transition-all shadow-lg hover:shadow-xl"
                >
                  Создать курс
                </button>
              </div>
            </form>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default CreateCourseModal;