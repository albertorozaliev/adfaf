import React, { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { X, Calendar, FileText, Clock, User, Edit } from 'lucide-react'
import GlassCard from './GlassCard'

export default function EditAssignmentModal({ isOpen, onClose, onSave, assignment }) {
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [dueDate, setDueDate] = useState('')
  const [dueTime, setDueTime] = useState('')
  const [maxGrade, setMaxGrade] = useState(5)

  // Заполняем форму данными задания при открытии
  useEffect(() => {
    if (assignment && isOpen) {
      setTitle(assignment.title || '')
      setDescription(assignment.description || '')
      
      // Парсим дату и время
      if (assignment.dueDate) {
        const dateObj = new Date(assignment.dueDate)
        setDueDate(dateObj.toISOString().split('T')[0])
        setDueTime(dateObj.toTimeString().slice(0, 5))
      }
      
      setMaxGrade(assignment.maxGrade || 5)
    }
  }, [assignment, isOpen])

  const handleSubmit = () => {
    if (!title.trim() || !description.trim() || !dueDate) {
      alert('Пожалуйста, заполните все обязательные поля')
      return
    }

    const updatedAssignment = {
      ...assignment,
      title: title.trim(),
      description: description.trim(),
      dueDate: `${dueDate}${dueTime ? `T${dueTime}` : ''}`,
      maxGrade: parseInt(maxGrade),
      lastModified: new Date().toISOString()
    }

    onSave(updatedAssignment)
    handleClose()
  }

  const handleClose = () => {
    setTitle('')
    setDescription('')
    setDueDate('')
    setDueTime('')
    setMaxGrade(5)
    onClose()
  }

  if (!assignment) return null

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
          onClick={handleClose}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="w-full max-w-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <GlassCard className="p-6 space-y-6">
              {/* Header */}
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-semibold">Редактировать задание</h2>
                  <p className="text-sm text-muted">Измените информацию о задании</p>
                </div>
                <button
                  onClick={handleClose}
                  className="glass rounded-full p-2 hover:bg-white/10 transition-colors"
                >
                  <X size={18} />
                </button>
              </div>

              {/* Form */}
              <div className="space-y-4">
                {/* Title */}
                <div>
                  <label className="block text-sm font-medium mb-2">Название задания *</label>
                  <input
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="Введите название задания..."
                    className="w-full glass rounded-xl px-4 py-3 bg-transparent border border-white/10 focus:border-white/20 outline-none transition-colors"
                  />
                </div>

                {/* Description */}
                <div>
                  <label className="block text-sm font-medium mb-2">Описание *</label>
                  <textarea
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Опишите задание подробно..."
                    rows={4}
                    className="w-full glass rounded-xl px-4 py-3 bg-transparent border border-white/10 focus:border-white/20 outline-none transition-colors resize-none"
                  />
                </div>

                {/* Due Date and Time */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Срок сдачи *</label>
                    <div className="relative">
                      <Calendar size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted" />
                      <input
                        type="date"
                        value={dueDate}
                        onChange={(e) => setDueDate(e.target.value)}
                        className="w-full glass rounded-xl pl-10 pr-4 py-3 bg-transparent border border-white/10 focus:border-white/20 outline-none transition-colors"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Время сдачи</label>
                    <div className="relative">
                      <Clock size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted" />
                      <input
                        type="time"
                        value={dueTime}
                        onChange={(e) => setDueTime(e.target.value)}
                        className="w-full glass rounded-xl pl-10 pr-4 py-3 bg-transparent border border-white/10 focus:border-white/20 outline-none transition-colors"
                      />
                    </div>
                  </div>
                </div>

                                 {/* Max Grade */}
                 <div>
                   <label className="block text-sm font-medium mb-2">Максимальная оценка</label>
                   <div className="relative">
                     <FileText size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted" />
                                           <select
                        value={maxGrade}
                        onChange={(e) => setMaxGrade(e.target.value)}
                        className="w-full glass rounded-xl pl-10 pr-12 py-3 bg-transparent border border-white/10 focus:border-white/20 outline-none transition-colors appearance-none cursor-pointer"
                      >
                                               <option value={3}>3 балла</option>
                        <option value={4}>4 балла</option>
                        <option value={5}>5 баллов</option>
                        <option value={10}>10 баллов</option>
                        <option value={100}>100 баллов</option>
                     </select>
                   </div>
                 </div>
              </div>

              {/* Actions */}
              <div className="flex gap-3 pt-4 border-t border-white/10">
                <button
                  onClick={handleClose}
                  className="flex-1 glass rounded-xl px-4 py-3 hover:bg-white/10 transition-colors"
                >
                  Отмена
                </button>
                <button
                  onClick={handleSubmit}
                  className="flex-1 glass rounded-xl px-4 py-3 bg-blue-500/20 hover:bg-blue-500/30 transition-colors flex items-center gap-2"
                >
                  <Edit size={16} />
                  Сохранить изменения
                </button>
              </div>
            </GlassCard>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
