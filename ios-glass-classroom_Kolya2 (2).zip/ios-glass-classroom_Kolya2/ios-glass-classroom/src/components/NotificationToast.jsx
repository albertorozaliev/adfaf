import React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { CheckCircle, X, Upload, FileText, Link, HardDrive } from 'lucide-react'
import GlassCard from './GlassCard'

export default function NotificationToast({ 
  isVisible, 
  onClose, 
  type = 'success', 
  title, 
  message, 
  attachments = [] 
}) {
  const getIcon = () => {
    switch (type) {
      case 'success':
        return <CheckCircle size={20} className="text-green-400" />
      case 'upload':
        return <Upload size={20} className="text-blue-400" />
      default:
        return <CheckCircle size={20} className="text-green-400" />
    }
  }

  const getTypeStyles = () => {
    switch (type) {
      case 'success':
        return 'border-green-500/20 bg-green-500/10'
      case 'upload':
        return 'border-blue-500/20 bg-blue-500/10'
      default:
        return 'border-green-500/20 bg-green-500/10'
    }
  }

  const getAttachmentIcon = (attachment) => {
    switch (attachment.type) {
      case 'file':
        return <FileText size={14} className="text-blue-400" />
      case 'link':
        return <Link size={14} className="text-green-400" />
      case 'drive':
        return <HardDrive size={14} className="text-purple-400" />
      default:
        return <FileText size={14} className="text-blue-400" />
    }
  }

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, y: -50, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -50, scale: 0.9 }}
          className="fixed top-4 right-4 z-50 max-w-sm"
        >
          <GlassCard className={`p-4 border ${getTypeStyles()}`}>
            <div className="flex items-start gap-3">
              <div className="glass rounded-full p-2 flex-shrink-0">
                {getIcon()}
              </div>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1">
                    <h3 className="font-semibold text-sm">{title}</h3>
                    <p className="text-xs text-muted mt-1">{message}</p>
                    
                    {/* Attachments List */}
                    {attachments.length > 0 && (
                      <div className="mt-3 space-y-1">
                        <div className="text-xs font-medium text-muted">Прикрепленные файлы:</div>
                        {attachments.slice(0, 3).map((attachment, index) => (
                          <div key={index} className="flex items-center gap-2 text-xs">
                            {getAttachmentIcon(attachment)}
                            <span className="truncate">{attachment.name}</span>
                          </div>
                        ))}
                        {attachments.length > 3 && (
                          <div className="text-xs text-muted">
                            +{attachments.length - 3} еще
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                  
                  <button
                    onClick={onClose}
                    className="glass rounded-full p-1 hover:bg-white/10 transition-colors flex-shrink-0"
                  >
                    <X size={14} />
                  </button>
                </div>
              </div>
            </div>
          </GlassCard>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
