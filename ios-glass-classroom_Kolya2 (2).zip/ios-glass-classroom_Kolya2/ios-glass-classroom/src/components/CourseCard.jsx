import React from 'react'
import { motion } from 'framer-motion'

export default function CourseCard({ title, teacher, color, colorClass, onClick }) {
  return (
    <motion.button
      onClick={onClick}
      className="rounded-3xl p-0 overflow-hidden text-left group shine h-full w-full flex flex-col"
      whileHover={{ y: -4 }}
      transition={{ type: 'spring', stiffness: 220, damping: 22 }}
    >
      <div 
        className={`h-32 relative flex-shrink-0 bg-gradient-to-r ${colorClass || ''}`}
        style={!colorClass ? { background: color } : {}}
      >
        <div className="absolute inset-0 backdrop-blur-[1px] bg-gradient-to-b from-black/10 via-black/5 to-black/30" />
        <div className="absolute -bottom-8 -right-8 w-40 h-40 rounded-full bg-white/5 blur-2xl" />
      </div>
                        <div className="glass p-5 -mt-6 mx-3 rounded-2xl relative flex-1 flex flex-col justify-center min-h-0">
                    <div className="font-semibold truncate text-base leading-tight">{title}</div>
                    <div className="text-sm text-muted mt-1 truncate leading-tight">{teacher}</div>
                    

                  </div>
    </motion.button>
  )
}
