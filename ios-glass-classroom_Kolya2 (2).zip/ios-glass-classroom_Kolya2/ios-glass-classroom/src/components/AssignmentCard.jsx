import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { Calendar, Clock, BookOpen, CheckCircle, Circle, FileText, Upload, Eye, Edit, Star } from 'lucide-react'
import AttachmentModal from './AttachmentModal'
import NotificationToast from './NotificationToast'
import { useAttachments } from '../hooks/useAttachments'
import { useGrades } from '../hooks/useGrades'

export default function AssignmentCard({
  title,
  description,
  dueDate,
  course,
  teacher,
  completed = false,
  progress = 0,
  grade: initialGrade = null,
  maxGrade = 5,
  onClick,
  courseId,
  assignmentId,
  lastModified
}) {
  const navigate = useNavigate()
  const [isAttachmentModalOpen, setIsAttachmentModalOpen] = useState(false)
  const [notification, setNotification] = useState({ isVisible: false, type: 'success', title: '', message: '', attachments: [] })
  const isOverdue = new Date(dueDate) < new Date()
  const daysUntilDue = Math.ceil((new Date(dueDate) - new Date()) / (1000 * 60 * 60 * 24))
  
  // Проверяем, сдано ли задание с опозданием
  const isSubmittedLate = completed && isOverdue
  
  const formatDateTime = (dateString) => {
    return new Date(dateString).toLocaleString('ru-RU', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }
  
  const { attachments, addAttachments } = useAttachments(assignmentId)
  const { grade } = useGrades(assignmentId)
  
  // Используем сохраненную оценку или начальную
  const currentGrade = grade || initialGrade

  const handleAttach = (attachments) => {
    addAttachments(attachments)
    
    // Подготавливаем данные для уведомления
    const formattedAttachments = []
    
    attachments.files.forEach(file => {
      formattedAttachments.push({
        type: 'file',
        name: file.name
      })
    })
    
    attachments.links.forEach(link => {
      if (link.trim()) {
        formattedAttachments.push({
          type: 'link',
          name: link
        })
      }
    })
    
    attachments.driveFiles.forEach(file => {
      formattedAttachments.push({
        type: 'drive',
        name: file.name
      })
    })
    
    // Показываем уведомление
    setNotification({
      isVisible: true,
      type: 'upload',
      title: 'Файлы прикреплены!',
      message: `Успешно прикреплено ${formattedAttachments.length} файлов к заданию`,
      attachments: formattedAttachments
    })
    
    // Автоматически скрываем уведомление через 5 секунд
    setTimeout(() => {
      setNotification(prev => ({ ...prev, isVisible: false }))
    }, 5000)
  }

  const handleViewDetails = (e) => {
    e.stopPropagation()
    if (onClick) onClick()
  }

  const handleCardClick = () => {
    if (onClick) onClick()
  }

  const handleAttachWork = (e) => {
    e.stopPropagation()
    setIsAttachmentModalOpen(true)
  }

  return (
         <motion.div
       className="group cursor-pointer"
       whileHover={{ y: -4 }}
       transition={{ type: 'spring', stiffness: 220, damping: 22 }}
       onClick={handleCardClick}
     >
       <div className="glass rounded-3xl p-6 relative overflow-hidden">
        {/* Background gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 via-purple-500/10 to-pink-500/10 opacity-50" />
        
        {/* Shine effect */}
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent -skew-x-12 -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
        
        {/* Content */}
        <div className="relative z-10">
          {/* Header */}
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className={`glass rounded-full p-2 ${completed ? 'bg-green-500/20' : 'bg-blue-500/20'}`}>
                {completed ? (
                  <CheckCircle size={20} className="text-green-400" />
                ) : (
                  <FileText size={20} className="text-blue-400" />
                )}
              </div>
              <div>
                <h3 className={`font-semibold ${completed ? 'line-through text-muted' : ''}`}>
                  {title}
                </h3>
                <p className="text-sm text-muted">{course} • {teacher}</p>
                {lastModified && (
                  <div className="text-xs text-muted mt-1 flex items-center gap-1">
                    <Edit size={12} />
                    Изменено: {formatDateTime(lastModified)}
                  </div>
                )}
              </div>
            </div>
                         <div className={`text-xs glass rounded-full px-3 py-1 ${
               isSubmittedLate ? 'bg-orange-500/20 text-orange-400' :
               completed ? 'bg-green-500/20 text-green-400' :
               isOverdue ? 'bg-red-500/20 text-red-400' :
               daysUntilDue <= 3 ? 'bg-yellow-500/20 text-yellow-400' :
               'bg-blue-500/20 text-blue-400'
             }`}>
               {isSubmittedLate ? 'Сдано с опозданием' :
                completed ? 'Завершено' :
                isOverdue ? 'Просрочено' :
                daysUntilDue === 0 ? 'Сдать сегодня' :
                daysUntilDue === 1 ? 'Сдать завтра' :
                `${daysUntilDue} дней осталось`}
             </div>
          </div>

          {/* Description */}
          <p className="text-sm text-muted mb-4 line-clamp-2">
            {description}
          </p>

          {/* Progress Bar */}
          <div className="mb-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">Прогресс</span>
              <span className="text-sm text-muted">{progress}%</span>
            </div>
            <div className="w-full h-3 glass rounded-full overflow-hidden">
              <div 
                className={`h-full transition-all duration-500 ${
                  completed ? 'bg-green-500' : 
                  progress > 50 ? 'bg-blue-500' : 
                  progress > 25 ? 'bg-yellow-500' : 'bg-gray-500'
                }`}
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>

                     {/* Grade */}
           {currentGrade !== null && (
             <div className="mb-4">
               <div className="flex items-center justify-between mb-2">
                 <span className="text-sm font-medium">Оценка</span>
                 <span className="text-sm font-semibold text-green-400">{currentGrade}/{maxGrade}</span>
               </div>
               <div className="w-full h-2 glass rounded-full overflow-hidden">
                 <div 
                   className="h-full bg-green-500 transition-all duration-500"
                   style={{ width: `${(currentGrade / maxGrade) * 100}%` }}
                 />
               </div>
             </div>
           )}

          {/* Due date */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2 text-xs text-muted">
              <Calendar size={14} />
              <span>Срок сдачи: {new Date(dueDate).toLocaleDateString('ru-RU')}</span>
            </div>
          </div>

          {/* Action buttons */}
          <div className="pt-4 border-t border-white/10 space-y-2">
            <button 
              onClick={handleViewDetails}
              className={`w-full glass rounded-2xl py-2 px-4 text-sm font-medium transition-colors flex items-center justify-center gap-2 ${
                completed 
                  ? 'bg-green-500/20 text-green-400 hover:bg-green-500/30' 
                  : 'bg-blue-500/20 text-blue-400 hover:bg-blue-500/30'
              }`}>
              <Eye size={16} />
              {completed ? 'Посмотреть работу' : 'Подробнее'}
            </button>
            {!completed && (
              <button 
                onClick={handleAttachWork}
                className="w-full glass rounded-2xl py-2 px-4 text-sm font-medium transition-colors flex items-center justify-center gap-2 bg-purple-500/20 text-purple-400 hover:bg-purple-500/30">
                <Upload size={16} />
                Прикрепить работу
              </button>
            )}
          </div>
        </div>
      </div>

             {/* Модальное окно прикрепления */}
       <AttachmentModal
         isOpen={isAttachmentModalOpen}
         onClose={() => setIsAttachmentModalOpen(false)}
         onAttach={handleAttach}
       />
       
       {/* Уведомления */}
       <NotificationToast
         isVisible={notification.isVisible}
         onClose={() => setNotification(prev => ({ ...prev, isVisible: false }))}
         type={notification.type}
         title={notification.title}
         message={notification.message}
         attachments={notification.attachments}
       />
     </motion.div>
   )
 }
