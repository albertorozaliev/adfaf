import React, { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { X, Star, StarOff } from 'lucide-react'
import GlassCard from './GlassCard'

export default function GradeModal({ isOpen, onClose, onSave, currentGrade = null, maxGrade = 5 }) {
  const [selectedGrade, setSelectedGrade] = useState(currentGrade || 0)
  const [hoveredGrade, setHoveredGrade] = useState(0)

  const handleSave = () => {
    if (selectedGrade > 0) {
      onSave(selectedGrade)
      onClose()
    }
  }

  const handleStarClick = (grade) => {
    setSelectedGrade(grade)
  }

  const handleStarHover = (grade) => {
    setHoveredGrade(grade)
  }

  const handleStarLeave = () => {
    setHoveredGrade(0)
  }

  const getGradeText = (grade) => {
    switch (grade) {
      case 5: return 'Отлично!'
      case 4: return 'Хорошо'
      case 3: return 'Удовлетворительно'
      case 2: return 'Неудовлетворительно'
      case 1: return 'Плохо'
      default: return 'Выберите оценку'
    }
  }

  const getGradeColor = (grade) => {
    switch (grade) {
      case 5: return 'text-yellow-400'
      case 4: return 'text-green-400'
      case 3: return 'text-blue-400'
      case 2: return 'text-orange-400'
      case 1: return 'text-red-400'
      default: return 'text-muted'
    }
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 20 }}
            className="w-full max-w-md"
            onClick={(e) => e.stopPropagation()}
          >
            <GlassCard className="p-6 space-y-6">
              {/* Header */}
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-semibold">Выставить оценку</h2>
                  <p className="text-sm text-muted">Выберите оценку от 1 до {maxGrade}</p>
                </div>
                <button
                  onClick={onClose}
                  className="glass rounded-full p-2 hover:bg-white/10 transition-colors"
                >
                  <X size={18} />
                </button>
              </div>

              {/* Stars */}
              <div className="space-y-4">
                <div className="flex justify-center gap-2">
                  {[1, 2, 3, 4, 5].map((grade) => (
                    <button
                      key={grade}
                      onClick={() => handleStarClick(grade)}
                      onMouseEnter={() => handleStarHover(grade)}
                      onMouseLeave={handleStarLeave}
                      className="transition-all duration-200 hover:scale-110"
                    >
                      {grade <= (hoveredGrade || selectedGrade) ? (
                        <Star 
                          size={32} 
                          className="text-yellow-400 fill-current drop-shadow-lg" 
                        />
                      ) : (
                        <StarOff 
                          size={32} 
                          className="text-muted hover:text-yellow-400/50 transition-colors" 
                        />
                      )}
                    </button>
                  ))}
                </div>

                {/* Grade Text */}
                <div className="text-center">
                  <div className={`text-lg font-semibold ${getGradeColor(selectedGrade)}`}>
                    {selectedGrade > 0 ? `${selectedGrade}/${maxGrade}` : '—'}
                  </div>
                  <div className={`text-sm ${getGradeColor(selectedGrade)}`}>
                    {getGradeText(selectedGrade)}
                  </div>
                </div>

                {/* Progress Bar */}
                {selectedGrade > 0 && (
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Прогресс</span>
                      <span>{Math.round((selectedGrade / maxGrade) * 100)}%</span>
                    </div>
                    <div className="w-full bg-white/10 rounded-full h-2">
                      <div
                        className="h-2 rounded-full bg-gradient-to-r from-red-500 via-yellow-500 to-green-500 transition-all duration-500"
                        style={{ width: `${(selectedGrade / maxGrade) * 100}%` }}
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Actions */}
              <div className="flex gap-3 pt-4 border-t border-white/10">
                <button
                  onClick={onClose}
                  className="flex-1 glass rounded-xl px-4 py-3 hover:bg-white/10 transition-colors"
                >
                  Отмена
                </button>
                <button
                  onClick={handleSave}
                  disabled={selectedGrade === 0}
                  className={`flex-1 glass rounded-xl px-4 py-3 transition-colors ${
                    selectedGrade > 0 
                      ? 'bg-green-500/20 hover:bg-green-500/30 text-green-400' 
                      : 'opacity-50 cursor-not-allowed'
                  }`}
                >
                  Сохранить
                </button>
              </div>
            </GlassCard>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
