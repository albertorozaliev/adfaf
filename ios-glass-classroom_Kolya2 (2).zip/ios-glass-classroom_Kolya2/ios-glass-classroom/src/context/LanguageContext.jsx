import React, { createContext, useContext, useState, useEffect } from 'react';

const LanguageContext = createContext();

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};

export const LanguageProvider = ({ children }) => {
  const [language, setLanguage] = useState(() => {
    const saved = localStorage.getItem('classroom-language');
    return saved || 'ru';
  });

  useEffect(() => {
    localStorage.setItem('classroom-language', language);
  }, [language]);

  const changeLanguage = (newLanguage) => {
    setLanguage(newLanguage);
  };

  const t = (key) => {
    const translations = {
      ru: {
        // Навигация
        'overview': 'Обзор',
        'my_courses': 'Мои курсы',
        'recent': 'Недавнее',
        'settings': 'Настройки',
        'back_to_courses': 'Назад к курсам',
        'assignments': 'Задания',
        'stream': 'Лента',
        'people': 'Участники',
        'grades': 'Оценки',
        
        // Действия
        'create_course': 'Создать курс',
        'create_assignment': 'Создать задание',
        'edit_assignment': 'Редактировать задание',
        'delete_course': 'Удалить курс',
        'attach_work': 'Прикрепить работу',
        'view_details': 'Подробнее',
        
        // Статусы
        'active': 'Активен',
        'completed': 'Завершено',
        'overdue': 'Просрочено',
        'due_today': 'Сдать сегодня',
        'due_tomorrow': 'Сдать завтра',
        'days_left': 'дней осталось',
        
        // Общие
        'teacher': 'Преподаватель',
        'student': 'Студент',
        'progress': 'Прогресс',
        'grade': 'Оценка',
        'due_date': 'Срок сдачи',
        'last_modified': 'Изменено',
        'attachments': 'Вложения',
        'no_attachments': 'Нет вложений',
        
        // Модальные окна
        'cancel': 'Отмена',
        'save': 'Сохранить',
        'close': 'Закрыть',
        'confirm': 'Подтвердить',
        
        // Уведомления
        'success': 'Успешно',
        'error': 'Ошибка',
        'warning': 'Предупреждение',
        'info': 'Информация'
      },
      en: {
        // Navigation
        'overview': 'Overview',
        'my_courses': 'My Courses',
        'recent': 'Recent',
        'settings': 'Settings',
        'back_to_courses': 'Back to Courses',
        'assignments': 'Assignments',
        'stream': 'Stream',
        'people': 'People',
        'grades': 'Grades',
        
        // Actions
        'create_course': 'Create Course',
        'create_assignment': 'Create Assignment',
        'edit_assignment': 'Edit Assignment',
        'delete_course': 'Delete Course',
        'attach_work': 'Attach Work',
        'view_details': 'View Details',
        
        // Statuses
        'active': 'Active',
        'completed': 'Completed',
        'overdue': 'Overdue',
        'due_today': 'Due Today',
        'due_tomorrow': 'Due Tomorrow',
        'days_left': 'days left',
        
        // General
        'teacher': 'Teacher',
        'student': 'Student',
        'progress': 'Progress',
        'grade': 'Grade',
        'due_date': 'Due Date',
        'last_modified': 'Last Modified',
        'attachments': 'Attachments',
        'no_attachments': 'No attachments',
        
        // Modals
        'cancel': 'Cancel',
        'save': 'Save',
        'close': 'Close',
        'confirm': 'Confirm',
        
        // Notifications
        'success': 'Success',
        'error': 'Error',
        'warning': 'Warning',
        'info': 'Information'
      },
      ger: {
        // Navigation
        'overview': 'Überblick',
        'my_courses': 'Meine Kurse',
        'recent': 'Kürzlich',
        'settings': 'Einstellungen',
        'back_to_courses': 'Zurück zu den Kursen',
        'assignments': 'Aufgaben',
        'stream': 'Stream',
        'people': 'Personen',
        'grades': 'Bewertungen',
        
        // Aktionen
        'create_course': 'Kurs erstellen',
        'create_assignment': 'Aufgabe erstellen',
        'edit_assignment': 'Aufgabe bearbeiten',
        'delete_course': 'Kurs löschen',
        'attach_work': 'Arbeit anhängen',
        'view_details': 'Details anzeigen',
        
        // Status
        'active': 'Aktiv',
        'completed': 'Abgeschlossen',
        'overdue': 'Überfällig',
        'due_today': 'Fällig heute',
        'due_tomorrow': 'Fällig morgen',
        'days_left': 'Tage verbleibend',
        
        // Allgemein
        'teacher': 'Lehrer',
        'student': 'Schüler/Student',
        'progress': 'Fortschritt',
        'grade': 'Note',
        'due_date': 'Fälligkeitsdatum',
        'last_modified': 'Zuletzt geändert',
        'attachments': 'Anhänge',
        'no_attachments': 'Keine Anhänge',
        
        // Modale Fenster
        'cancel': 'Abbrechen',
        'save': 'Speichern',
        'close': 'Schließen',
        'confirm': 'Bestätigen',
        
        // Benachrichtigungen
        'success': 'Erfolg',
        'error': 'Fehler',
        'warning': 'Warnung',
        'info': 'Information'
      },
      fr: {
        // Navigation
        'overview': 'Aperçu',
        'my_courses': 'Mes cours',
        'recent': 'Récent',
        'settings': 'Paramètres',
        'back_to_courses': 'Retour aux cours',
        'assignments': 'Devoirs',
        'stream': 'Flux',
        'people': 'Personnes',
        'grades': 'Notes',
        
        // Actions
        'create_course': 'Créer un cours',
        'create_assignment': 'Créer un devoir',
        'edit_assignment': 'Modifier le devoir',
        'delete_course': 'Supprimer le cours',
        'attach_work': 'Joindre le travail',
        'view_details': 'Voir les détails',
        
        // Statuts
        'active': 'Actif',
        'completed': 'Terminé',
        'overdue': 'En retard',
        'due_today': 'À remettre aujourd\'hui',
        'due_tomorrow': 'À remettre demain',
        'days_left': 'jours restants',
        
        // Général
        'teacher': 'Professeur',
        'student': 'Élève/Étudiant',
        'progress': 'Progrès',
        'grade': 'Note',
        'due_date': 'Date d\'échéance',
        'last_modified': 'Modifié le',
        'attachments': 'Pièces jointes',
        'no_attachments': 'Aucune pièce jointe',
        
        // Fenêtres modales
        'cancel': 'Annuler',
        'save': 'Enregistrer',
        'close': 'Fermer',
        'confirm': 'Confirmer',
        
        // Notifications
        'success': 'Succès',
        'error': 'Erreur',
        'warning': 'Avertissement',
        'info': 'Information'
      }
    };

    return translations[language]?.[key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, changeLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};
